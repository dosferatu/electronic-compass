Source code can be found in separate directories.

The binaries in this directory is compiled with the
free Bloodshed Dev-C++ 4.9.9.0 compiler available at
http://www.bloodshed.net/devcpp.html

