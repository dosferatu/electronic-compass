/*This file is prepared for Doxygen automatic documentation generation.*/
//! \file *********************************************************************
//!
//! \brief Routines to control EEPROM
//!
//! - Compiler:           IAR EWAVR and GNU GCC for AVR
//! - Supported devices:  ATmega32U4
//!
//! \author               Atmel Corporation: http://www.atmel.com \n
//!                       Support and FAQ: http://support.atmel.no/
//!
//! ***************************************************************************

/* Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*_____ I N C L U D E S ____________________________________________________*/
#define _EEP_LIB_C_
#include "config.h"
#include "eep_drv.h"
#include "eep_lib.h"

/*_____ M A C R O S ________________________________________________________*/

/*_____ D E F I N I T I O N S ______________________________________________*/
#ifndef EEPROM_SIZE
#error You must define EEPROM_SIZE in bytes in config.h
#else


bit eeprom_erase(void)
{
#if EEPROM_SIZE > 0
register Uint16 addr;

Enable_eeprom();
addr=0;
do {
  while (eeprom_busy());
  eeprom_wr(addr,EEPROM_BLANK_VALUE);
  } while (addr++!=(EEPROM_SIZE-1));
Disable_eeprom();
#endif
return TRUE;
}

bit eeprom_wr_byte (Uint16 addr, Uchar value)
{
Enable_eeprom();
while (eeprom_busy());
eeprom_wr(addr,value);
Disable_eeprom();
return TRUE;
} 


Byte eeprom_rd_byte (Uint16 addr)
{
register Byte b;
  while (eeprom_busy());
Enable_eeprom();
b=eeprom_rd(addr);
Disable_eeprom();
return b;
} 



bit eeprom_rd_block (Uint16 src, Byte _MemType_* dest, Byte n)
{
  while (eeprom_busy());
Enable_eeprom();
for (;n--;++src) *dest++=eeprom_rd(src);
Disable_eeprom();
return TRUE;
}



bit eeprom_wr_block (Byte _MemType_* src, Uint16 dest, U16 n)
{
#if EEPROM_SIZE > 0

Enable_eeprom();
for (;n--;)
  {
  while (eeprom_busy());
  eeprom_wr(dest,*src++);
  if (dest++==(EEPROM_SIZE-1)) break; // page not aligned on boundary EEPROM memory block
  } 
Disable_eeprom();
#endif
return TRUE;
}

#endif

