/*This file is prepared for Doxygen automatic documentation generation.*/
//! \file *********************************************************************
//!
//! \brief This file contains SPI lib header file
//!
//! - Compiler:           IAR EWAVR and GNU GCC for AVR
//! - Supported devices:  ATmega32U4
//!
//! \author               Atmel Corporation: http://www.atmel.com \n
//!                       Support and FAQ: http://support.atmel.no/
//!
//! ***************************************************************************

/* Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef _SPI_LIB_H_
#define _SPI_LIB_H_

//_____ I N C L U D E - F I L E S ____________________________________________

#include "lib_mcu/spi/spi_drv.h"


//_____ P R O T O T Y P E S ____________________________________________________________

//! This function configures the SPI controller in master
//!
//! @param mode          SPI_MODE_0 to SPI_MODE_3
//! @param rate          SPI_RATE_0 to SPI_RATE_6
//! @param b_msb_first   TRUE if the MSB of the data word is transmitted first
//!
//! @return    FALSE in case of error
//! @return    TRUE, initialization OK
//!
bit spi_init_master( U8 mode, U8 rate, Bool b_msb_first );


//! This function configures the SPI controller in slave
//!
//! @param mode          SPI_MODE_0 to SPI_MODE_3
//! @param rate          SPI_RATE_0 to SPI_RATE_6
//! @param b_msb_first   TRUE if the MSB of the data word is transmitted first
//!
//! @return    FALSE in case of error
//! @return    TRUE, initialization OK
//!
bit spi_init_slave( U8 mode, U8 rate, Bool b_msb_first );


//! This function sends a byte on the SPI
//!
//! @param uc_wr_byte   character to send on the SPI
//!
//! @return    character sent
//!
char spi_putchar( char uc_wr_byte );


//! This function checks if a bytes has been received on the SPI
//!
//! @return TRUE if byte received
//!
bit  spi_test_hit( void );


//! This function reads a byte on the SPI
//!
//! @return    character read
//!
char spi_getchar( void );


//! SPI Make the transmission possible
//!
//! @param cData         the data byte to send
//!
void spi_transmit_master( char cData );


//! This function sends a byte on SPI interface
//!
//! @param tx            the data byte to send
//!
//! @return    the received byte
//!
char spi_rw( char tx );


#endif // _SPI_LIB_H_

