/*This file is prepared for Doxygen automatic documentation generation.*/
//! \file *********************************************************************
//!
//! \brief This file contains a set of routines to perform flash access.
//!
//! - Compiler:           IAR EWAVR and GNU GCC for AVR
//! - Supported devices:  ATmega32U4
//!
//! \author               Atmel Corporation: http://www.atmel.com \n
//!                       Support and FAQ: http://support.atmel.no/
//!
//! ***************************************************************************

/* Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*_____ I N C L U D E S ____________________________________________________*/
#include "config.h"
#include "flash_boot_lib.h"
#include "flash_boot_drv.h"


#ifndef FLASH_SIZE
#error You must define FLASH_SIZE in bytes in config.h
#endif



/*_____ M A C R O S ________________________________________________________*/

/*_____ D E F I N I T I O N S ______________________________________________*/

/*_____ D E C L A R A T I O N S ____________________________________________*/


#pragma location="BOOT"
void flash_wr_byte(U16 addr_byte, Uchar value)
{
  Enable_flash();
  flash_wr_block(&value, addr_byte, 1);
  Disable_flash();
}


#pragma location="BOOT"
Uchar flash_wr_block(Byte _MemType_* src, U16 dst, U16 n)
{
   U16 nb_word, temp16;
   U16 address;
   U16 save_page_adr;

   while(n)  // While there is data to load from src buffer
   {
      address=dst-(LOW(dst)%FLASH_PAGE_SIZE); // Compute the start of the page to be modified
      save_page_adr=address; //memorize page addr
      // For each word in this page
      for(nb_word=0;nb_word<FLASH_PAGE_SIZE/2;nb_word++)
      {
         if(n) //Still some data to load from src
         {
            if(address>=dst) //current address is inside the target range adr
            {
               MSB(temp16)=(*(U8*)src); //load MSB of word from buffer src
               src++; n--;
               if(n) //Still some data to load ?
               {
                  LSB(temp16)=(*(U8*)src); //load LSB of word from buffer src
                  src++; n--;
               }
               else  //only the MSB of the working belong to src buffer
               {     //load LSB form exisying flash
                  LSB(temp16)=flash_rd_byte((U8 farcode*)address+1);
               }
            }
            else  //current word addr out of dst target
            {     //load MSB from existing flash
               MSB(temp16)=flash_rd_byte((U8 farcode*)address);
               if(address+1==dst) // Is LSB word addr in dst range ?
               {
                  LSB(temp16)=(*(U8*)src);
                  src++; n--;
               }
               else // LSB read from existing flash
               {
                  LSB(temp16)=flash_rd_byte((U8 farcode*)address+1);
               }
            }
         }
         else  //complete page with words from existing flash
         {
            temp16=flash_rd_word((Uint16 farcode*)address);
         }
         flash_fill_temp_buffer(temp16,address);
         address+=2;
      }
      address=save_page_adr;
      for(nb_word=0;nb_word<FLASH_PAGE_SIZE/2;nb_word++)
      {
         if(flash_rd_word((Uint16 farcode*)address)!=0xFFFF)
         {
            Flash_page_erase(save_page_adr);
            break;
         }
         address+=2;
      }
      Flash_page_write(save_page_adr);

      //- First Flash address update for the next page
      address = save_page_adr + FLASH_PAGE_SIZE;

   }
   return TRUE;
}
#pragma location="BOOT"
void flash_erase(void)
{
#if FLASH_SIZE > 0
  U16 nb_page;

  Enable_flash();
  nb_page=0;
  do {
    Flash_page_erase(nb_page);
    nb_page += FLASH_PAGE_SIZE;
  } while (nb_page<(FLASH_SIZE));
  Disable_flash();
#endif

}

Uchar flash_rd_byte(Uchar farcode* addr)
{
  unsigned char temp;

  Enable_flash();
  temp = *addr;
  Disable_flash();
  return temp;
}


Uint16 flash_rd_word(Uint16 farcode* addr)
{
  Union16 temp;

  Enable_flash();
  temp.b[1] = flash_rd_byte ((Uchar farcode*) addr);
  temp.b[0] = flash_rd_byte ((Uchar farcode*)addr+1);
  Disable_flash();

  return temp.w;
}



