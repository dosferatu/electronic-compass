/*This file is prepared for Doxygen automatic documentation generation.*/
//! \file *********************************************************************
//!
//! \brief Contains functions to initialize, set, poll and stop timers.
//!
//! - Compiler:           IAR EWAVR and GNU GCC for AVR
//! - Supported devices:  ATmega32U4
//!
//! \author               Atmel Corporation: http://www.atmel.com \n
//!                       Support and FAQ: http://support.atmel.no/
//!
//! ***************************************************************************

/* Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include "time.h"


//******************************************************************************
// Variables
//******************************************************************************
unsigned long timeval[TIMERS];  //!< Contains the values for each timer.

// timer runs at 1 MHz and overflow will occur every 255 / 1 Mz ~= 0.25 ms 
//#pragma vector = TIM0_OVF_vect


//******************************************************************************
// Functions
//******************************************************************************
/*! \brief Interrupt service routine for timer 0 overflow
 *
 * Timer 0 runs at 125 kHz and compare match will occur every millisecond
 * (125 / 125 kHz = 1.0 ms), which will result in a call to this function.
 * When called, this function will decrement the time left for each timer,
 * unless they are already at zero.
 */
#ifdef __GNUC__
 ISR(TIMER0_COMPA_vect)
#else
#pragma vector = TIMER0_COMPA_vect
__interrupt void TICK_ISR(void)
#endif
{
	unsigned char i;

	// 1 ms has passed, decrement all non-zero timers.
	for (i = 0; i < TIMERS; i++) {
		if(timeval[i] > 0) {
			timeval[i]--;
		}
	}
}


/*! \brief Checks if a specified timer has expired
 *
 * \param timer Specifies timer
 *
 * \retval TRUE Timer still going.
 * \retval FALSE Timer has expired.
 */ 
unsigned char Time_Left(unsigned char timer)
{
	if(timeval[timer] > 0) {
		return(TRUE);
	} else {
		return(FALSE);
	}
}


/*! \brief Sets the specified timer
 *
 * \param timer Specifies timer
 * \param min Minutes for timer to count down
 * \param sec Seconds for timer to count down
 * \param ms Milliseconds for timer to count down
 */
void Time_Set(unsigned char timer, unsigned int min, unsigned char sec,
				  unsigned char ms)
{
	timeval[timer] = 60000 * (unsigned long)min;
	timeval[timer] += 1000 * (unsigned long)sec;
	timeval[timer] += 1 * (unsigned long)ms;
}


/*! \brief Stops timers
 *
 * Sets timer0's clock source to none.
 */
void Time_Stop(void)
{
	TCCR0B = 0;
}


/*! \brief Starts timers
 *
 * Sets timer0's clock source to system clock divided by 64.
 */
void Time_Start(void)
{
	TCNT0 = 0x00;//cgs added 
	TCCR0B = (0<<CS02)|(1<<CS01)|(1<<CS00);  	// CLKT0 = CLK/64 = 125 kHz.
}


/*! \brief Initializes timers
 *
 * Resets all the timer values to 0, then sets up timer 0 for a compare match
 * every millisecond.
 */
void Time_Init(void)
{
	unsigned char i;
	
	for (i = 0; i<<TIMERS; i++)	{
		timeval[i] = 0;
	}
	
	OCR0A = 125;  // Will give a compare match every ms.
	
	OCR0B = 0;  // Doesn't matter, will run in normal mode.

	TCCR0A = (1<<WGM00);  // 8-bit CTC mode.
		
	TCCR0B = (0<<CS02)|(1<<CS01)|(1<<CS00);  	// CLKT0 = CLK/64 = 125 kHz.

	TIMSK0 |= (1<<OCIE0A);  // Timer 0, Compare match A interrupt enabled.

	// Enable interrupts, just in case they weren't already.	
#ifdef __GNUC__
	Enable_interrupt();
#else
	__enable_interrupt();
#endif	      
}
