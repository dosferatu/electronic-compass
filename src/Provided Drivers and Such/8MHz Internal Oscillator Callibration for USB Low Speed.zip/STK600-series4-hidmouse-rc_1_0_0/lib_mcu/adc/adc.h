/*This file is prepared for Doxygen automatic documentation generation.*/
//! \file *********************************************************************
//!
//! \brief Contains definitions for ADC setup, and minimum supply voltage.
//!
//! - Compiler:           IAR EWAVR and GNU GCC for AVR
//! - Supported devices:  ATmega32U4
//!
//! \author               Atmel Corporation: http://www.atmel.com \n
//!                       Support and FAQ: http://support.atmel.no/
//!
//! ***************************************************************************

/* Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */#ifndef ADC_H
#define ADC_H

//******************************************************************************
// ADC setup
//******************************************************************************

//IBAT measurement

#if (TARGET_BOARD == MEGAU4EK)
  #define   R_SHUNT_OHMS 1		
  #define   R1_OHMS 10		// ADC1,ADC0 divider: R1*(R1 + R2)
  #define   R2_OHMS 30
  #define	VREF_I 246L		// ADC voltage reference for IBAT (x100)
  #define	VREF_V 2462L	// ADC voltage reference for IBAT (x1000)
#endif

#if (TARGET_BOARD == BC101)
  #define   R_SHUNT_OHMS 1		
  #define   R1_OHMS 13		// ADC1,ADC0 divider: R1*(R1 + R2)
  #define   R2_OHMS 10
  #define	VREF_I 256L		// ADC voltage reference for IBAT (x100)
  #define	VREF_V 2560L	// ADC voltage reference for IBAT (x1000)

#endif

#if (TARGET_BOARD == EVK527)
  #define   R_SHUNT_OHMS 1		
  #define   R1_OHMS 13		// ADC1,ADC0 divider: R1*(R1 + R2)
  #define   R2_OHMS 10
  #define	VREF_I 256L		// ADC voltage reference for IBAT (x100)
  #define	VREF_V 2560L	// ADC voltage reference for IBAT (x1000)
#endif

#define ADC_GAIN 10		    // ADC gain x10
#define ADC_ACCURACY 512L	// 8 bits accuracy in differential mode

//Result in mV x1000 = (vref x100)(ADC gain x10) 
#define I_SCALE_1 ((R1_OHMS + R2_OHMS)*(VREF_I))
#define I_SCALE_2 (R_SHUNT_OHMS * R1_OHMS * ADC_ACCURACY)

#define VBAT_SCALE_1 (long)((R1_OHMS + R2_OHMS)*(VREF_V))
#define VBAT_SCALE_2  (long)(R1_OHMS * ADC_ACCURACY * 2)

//******************************************************************************
// Global variables
//******************************************************************************
//cgs extern __eeprom unsigned char VBAT_RANGE;   
extern unsigned char VBAT_RANGE;   
extern volatile ADC_Status_t ADCS;


//******************************************************************************
// Function prototypes
//******************************************************************************
#ifdef __GNUC__
 ISR(ADC_vect);
#else
#pragma vector = ADC_vect
__interrupt void ADC_ISR(void);
#endif

unsigned int ScaleU(unsigned int data);
unsigned int ScaleI(unsigned int data);
void ADC_Wait(void);
void ADC_Init(void);

#endif // ADC_H
