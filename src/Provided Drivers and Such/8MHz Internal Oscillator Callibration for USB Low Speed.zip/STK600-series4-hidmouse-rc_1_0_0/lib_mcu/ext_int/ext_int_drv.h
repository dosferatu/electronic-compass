/*This file is prepared for Doxygen automatic documentation generation.*/
//! \file *********************************************************************
//!
//! \brief This file contains the low level macros and definition for external interrupts
//!
//! - Compiler:           IAR EWAVR and GNU GCC for AVR
//! - Supported devices:  ATmega32U4
//!
//! \author               Atmel Corporation: http://www.atmel.com \n
//!                       Support and FAQ: http://support.atmel.no/
//!
//! ***************************************************************************

/* Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef EXT_INT_DRV_H
#define EXT_INT_DRV_H

//_____ I N C L U D E S ____________________________________________________


//! @defgroup External Interrupt
//! External Interrupt Module
//! @{
//_____ M A C R O S ________________________________________________________

   //! @defgroup External interupt enable
   //! Low level macros that allow to enable external interrupt.
   //! @{
#define Enable_int0_interrupt()  (EIMSK|=(1<<INT0))
#define Enable_int1_interrupt()  (EIMSK|=(1<<INT1))
#define Enable_int2_interrupt()  (EIMSK|=(1<<INT2))
#define Enable_int3_interrupt()  (EIMSK|=(1<<INT3))
#define Enable_int4_interrupt()  (EIMSK|=(1<<INT4))
#define Enable_int5_interrupt()  (EIMSK|=(1<<INT5))
#define Enable_int6_interrupt()  (EIMSK|=(1<<INT6))
#define Enable_int7_interrupt()  (EIMSK|=(1<<INT7))
   //! @}

   //! @defgroup External interupt enable
   //! Low level macros that allow to enable external interrupt.
   //! @{
#define Disable_int0_interrupt()  (EIMSK&=~(1<<INT0))
#define Disable_int1_interrupt()  (EIMSK&=~(1<<INT1))
#define Disable_int2_interrupt()  (EIMSK&=~(1<<INT2))
#define Disable_int3_interrupt()  (EIMSK&=~(1<<INT3))
#define Disable_int4_interrupt()  (EIMSK&=~(1<<INT4))
#define Disable_int5_interrupt()  (EIMSK&=~(1<<INT5))
#define Disable_int6_interrupt()  (EIMSK&=~(1<<INT6))
#define Disable_int7_interrupt()  (EIMSK&=~(1<<INT7))
   //! @}

   //! @defgroup External PinChange interupt enable
   //! Low level macros that allow to enable external PinChange interrupt.
   //! @{
#define Enable_pc_interrupt()      (PCICR|=(1<<PCIE0))
#define Enable_pcint0_interrupt()  (PCMSK0|=(1<<PCINT0),Enable_pc_interrupt())
#define Enable_pcint1_interrupt()  (PCMSK0|=(1<<PCINT1),Enable_pc_interrupt())
#define Enable_pcint2_interrupt()  (PCMSK0|=(1<<PCINT2),Enable_pc_interrupt())
#define Enable_pcint3_interrupt()  (PCMSK0|=(1<<PCINT3),Enable_pc_interrupt())
#define Enable_pcint4_interrupt()  (PCMSK0|=(1<<PCINT4),Enable_pc_interrupt())
#define Enable_pcint5_interrupt()  (PCMSK0|=(1<<PCINT5),Enable_pc_interrupt())
#define Enable_pcint6_interrupt()  (PCMSK0|=(1<<PCINT6),Enable_pc_interrupt())
#define Enable_pcint7_interrupt()  (PCMSK0|=(1<<PCINT7),Enable_pc_interrupt())
   //! @}

   //! @defgroup External PinChange interupt Disable
   //! Low level macros that allow to Disable external PinChange interrupt.
   //! @{
#define Disable_pc_interrupt()      (PCICR|=~(1<<PCIE0))
#define Disable_pcint0_interrupt()  (PCMSK0&=~(1<<PCINT0))
#define Disable_pcint1_interrupt()  (PCMSK0&=~(1<<PCINT1))
#define Disable_pcint2_interrupt()  (PCMSK0&=~(1<<PCINT2))
#define Disable_pcint3_interrupt()  (PCMSK0&=~(1<<PCINT3))
#define Disable_pcint4_interrupt()  (PCMSK0&=~(1<<PCINT4))
#define Disable_pcint5_interrupt()  (PCMSK0&=~(1<<PCINT5))
#define Disable_pcint6_interrupt()  (PCMSK0&=~(1<<PCINT6))
#define Disable_pcint7_interrupt()  (PCMSK0&=~(1<<PCINT7))
   //! @}

   //! @defgroup External interupt 0 configuration
   //! Low level macros that allow to configure the external int0 interrupt.
   //! @{
#define Configure_int0_low_level()     (EICRA&=~((1<<ISC00)+(1<<ISC01)))
#define Configure_int0_logic_change()  (EICRA|=(1<<ISC00),EICRA&=~(1<<ISC01))
#define Configure_int0_falling_edge()  (EICRA&=~(1<<ISC00),EICRA|=(1<<ISC01))
#define Configure_int0_rising_edge()   (EICRA|=(1<<ISC00)+(1<<ISC01))
   //! @}

   //! @defgroup External interupt 1 configuration
   //! Low level macros that allow to configure the external int1 interrupt.
   //! @{
#define Configure_int1_low_level()     (EICRA&=~((1<<ISC10)+(1<<ISC11)))
#define Configure_int1_logic_change()  (EICRA|=(1<<ISC10),EICRA&=~(1<<ISC11))
#define Configure_int1_falling_edge()  (EICRA&=~(1<<ISC10),EICRA|=(1<<ISC11))
#define Configure_int1_rising_edge()   (EICRA|=(1<<ISC10)+(1<<ISC11))
   //! @}

   //! @defgroup External interupt 2 configuration
   //! Low level macros that allow to configure the external int2 interrupt.
   //! @{
#define Configure_int2_low_level()     (EICRA&=~((1<<ISC20)+(1<<ISC21)))
#define Configure_int2_logic_change()  (EICRA|=(1<<ISC20),EICRA&=~(1<<ISC21))
#define Configure_int2_falling_edge()  (EICRA&=~(1<<ISC20),EICRA|=(1<<ISC21))
#define Configure_int2_rising_edge()   (EICRA|=(1<<ISC20)+(1<<ISC21))
   //! @}

   //! @defgroup External interupt 3 configuration
   //! Low level macros that allow to configure the external int3 interrupt.
   //! @{
#define Configure_int3_low_level()     (EICRA&=~((1<<ISC30)+(1<<ISC31)))
#define Configure_int3_logic_change()  (EICRA|=(1<<ISC30),EICRA&=~(1<<ISC31))
#define Configure_int3_falling_edge()  (EICRA&=~(1<<ISC30),EICRA|=(1<<ISC31))
#define Configure_int3_rising_edge()   (EICRA|=(1<<ISC30)+(1<<ISC31))
   //! @}

   //! @defgroup External interupt 4 configuration
   //! Low level macros that allow to configure the external int4 interrupt.
   //! @{
#define Configure_int4_low_level()     (EICRB&=~((1<<ISC40)+(1<<ISC41)))
#define Configure_int4_logic_change()  (EICRB|=(1<<ISC40),EICRB&=~(1<<ISC41))
#define Configure_int4_falling_edge()  (EICRB&=~(1<<ISC40),EICRB|=(1<<ISC41))
#define Configure_int4_rising_edge()   (EICRB|=(1<<ISC40)+(1<<ISC41))
   //! @}

   //! @defgroup External interupt 5 configuration
   //! Low level macros that allow to configure the external int5 interrupt.
   //! @{
#define Configure_int5_low_level()     (EICRB&=~((1<<ISC50)+(1<<ISC51)))
#define Configure_int5_logic_change()  (EICRB|=(1<<ISC50),EICRB&=~(1<<ISC51))
#define Configure_int5_falling_edge()  (EICRB&=~(1<<ISC50),EICRB|=(1<<ISC51))
#define Configure_int5_rising_edge()   (EICRB|=(1<<ISC50)+(1<<ISC51))
   //! @}

   //! @defgroup External interupt 6 configuration
   //! Low level macros that allow to configure the external int6 interrupt.
   //! @{
#define Configure_int6_low_level()     (EICRB&=~((1<<ISC60)+(1<<ISC61)))
#define Configure_int6_logic_change()  (EICRB|=(1<<ISC60),EICRB&=~(1<<ISC61))
#define Configure_int6_falling_edge()  (EICRB&=~(1<<ISC60),EICRB|=(1<<ISC61))
#define Configure_int6_rising_edge()   (EICRB|=(1<<ISC60)+(1<<ISC61))
   //! @}

   //! @defgroup External interupt 7 configuration
   //! Low level macros that allow to configure the external int7 interrupt.
   //! @{
#define Configure_int7_low_level()     (EICRB&=~((1<<ISC70)+(1<<ISC71)))
#define Configure_int7_logic_change()  (EICRB|=(1<<ISC70),EICRB&=~(1<<ISC71))
#define Configure_int7_falling_edge()  (EICRB&=~(1<<ISC70),EICRB|=(1<<ISC71))
#define Configure_int7_rising_edge()   (EICRB|=(1<<ISC70)+(1<<ISC71))
   //! @}

//! @}


//_____ D E F I N I T I O N S ______________________________________________

//_____ F U N C T I O N S __________________________________________________


#endif  // EXT_INT_DRV_H
