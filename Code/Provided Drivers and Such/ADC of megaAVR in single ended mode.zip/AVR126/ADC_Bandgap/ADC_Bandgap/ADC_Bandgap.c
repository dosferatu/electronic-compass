
/* This ADC_Bandgap.c file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *
 *      ATmega88 ADC driver source file in C that measures Internal Band gap voltage
 *
 *      This ADC_Bandgap.c file contains the function that measures input on ADC Channel 0 and once
 * 	    the switch is pressed, it measures the internal band gap reference value.
 *	    BOD must be enabled to get more accurate values of internal band gap reference.
 *
 *      The driver is not intended for size and/or speed critical code, since
 *      most functions are just a few lines of code, and the function call
 *      overhead would decrease code performance. The driver is intended for
 *      rapid prototyping and documentation purposes for getting started with
 *      the ATmega88 ADC module.
 *
 * \par Application note:
 *      AVR126: Using ADC of ATmega88
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 * Copyright (c) 2011, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#define F_CPU 8000000UL

unsigned int count,result,BGval,GNDval;

/*! \brief Initializes ADC Peripheral Configuration Registers */

void initialize(void)
{
	ADCSRA   = 0b10000100;        			// Enable ADC with Clock prescaled by 16 ; If Clock speed is 8MHz, then ADC clock = 8MHz/16 = 500kHz
	DIDR0    = 0b00111111;        			// Disable Digital Input on ADC Channel 0 to reduce power consumption
    ADMUX    = 0b01000000;       			// Disable Left-Adjust and select Internal 1.1V reference and ADC Channel 0 as input
    count    = 0;
}

/*! \brief ADC Conversion Routine in single ended mode */

void convert(void)
{

	ADCSRA  |= (1<<ADSC);					// Start ADC Conversion

	while((ADCSRA & (1<<ADIF)) != 0x10);	// Wait till conversion is complete

	result   = ADC;                         // Read the ADC Result
	ADCSRA  |= (1 << ADIF);					// Clear ADC Conversion Interrupt Flag

}

/*! \brief Simple function to measure GND value from Internal ADC Channel
 *  Clear interrupts
 *  Selects AVcc as ADC reference voltage
 *  Selects Internal channel for measuring GND as input to ADC
 *  Ground is selected as ADC input channel to discharge the capacitor in ADC
 */
void MeasureGND()
{

	ADMUX =0b01001111; 						//Select AVcc as reference and 0V (GND) as input to ADC
	ADCSRA=0b11000100;						//Enable ADC with Clock prescaled by 16 and Start conversion

	while((ADCSRA & (1<<ADIF)) != 0x10);	//Wait till conversion is complete and then read the GND value

	GNDval=ADC;                      		//Read the measured ADC Value

	ADCSRA |=(1 << ADIF);					//Clear ADC Conversion Interrupt Flag
}

/*! \brief Simple function to measure Band gap reference value from Internal ADC Channel
 *
 *  Selects AVcc as ADC reference voltage
 *  Selects Internal channel for measuring bandgap reference as input to ADC
 *  Wait 70 us for the internal capacitor to charge before measuring
 */

void MeasureCurrentBGsingle()
{
	ADMUX =0b01001110; 						//Select AVcc as ADC reference and 1.1V (Vbg) as input to ADC
	ADCSRA=0b10000100;						//Enable ADC with clock prescaled by 16

	_delay_us(70);							//Wait for 70 uS (refer section:electrical characteristics -> system and reset characteristics for
											//Bandgap Reference start up time (70us) in the device datasheet.)
	ADCSRA |= (1<<ADSC);					//Start ADC Conversion

	while((ADCSRA & (1<<ADIF)) != 0x10);	//Wait till conversion is complete
	BGval=ADC;

	ADCSRA |=(1 << ADIF);					//Clear ADC Conversion Interrupt Flag
    initialize();

}

/*! \brief Main routine
 *  Calls function "initialize()" to initialize ADC
 *  Calls function "convert()" to convert the ADC sample when switch is not pressed
 *  Waits till the switch is pressed to measure Band gap
 *  Ground is measured before measuring band gap reference to discharge the capacitor
 */

int main(void)
{

	initialize();							//initialize the ADC Module

	while(1)
	{
		convert();

		while((PINB & (1<<0)) != 1)			//Wait for switch (Port B.0) press
		{
			while((PINB & (1<<0)) != 1);	//Wait till switch (Port B.0) is released
			MeasureGND();					//Dummy GND measurement
			MeasureCurrentBGsingle();   	//Measuring BG value when ever the switch is pressed
		}
	}

}

