/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Charge functions
 *
 *      Contains the functions for charging with constant current and voltage,
 *      and for deciding when to halt.
 *
 * \par Application note:
 *      AVRxxx: Lithium-Ion battery charging via USB with ATMega32U4  \n
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler 
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 * 
 * $Name$
 * $Revision:$
 * $RCSfile$
 * $URL:$
 * $Date:$\n
 ******************************************************************************/
#include "config.h"
#include "enums.h"
#include "structs.h"

#ifdef __GNUC__
   #include "lib_mcu/adc/adc.h"
   #include "lib_mcu/pwm/pwm.h"
   #include "lib_mcu/timer/time.h"
#elif __ICCAVR__
   #include "adc.h"  
   #include "PWM.h"
   #include "time.h"
#else
   #error Current COMPILER not supported
#endif

#include "battery.h"
#include "chargefunc.h"
#include "main.h"
#include "menu.h"
#include "statefunc.h"

#ifdef NIMH
#include "NIMHspecs.h"
#endif // NIMH

#ifdef LIION
#include "LIIONspecs.h"
#endif // LIION


//******************************************************************************
// Variables
//******************************************************************************
//! Struct that holds parameters for ConstantCurrent() and ConstantVoltage().
ChargeParameters_t ChargeParameters;

//! Struct that holds parameters for HaltNow().
HaltParameters_t HaltParameters;


//******************************************************************************
// Functions
//******************************************************************************
/*! \brief Charges battery with a constant current.
 *
 * This function applies a constant current (set in ChargeParameters.Current)
 * to the battery until HaltNow() returns TRUE, or a PWM error occurs and
 * \ref ABORT_IF_PWM_MIN or \ref ABORT_IF_PWM_MAX is defined.\n
 * The charge current can vary with +/- \ref BAT_CURRENT_HYST.\n
 * If the Master inhibits charging, timers are stopped and PWM output dropped.
 * Once the battery is no longer flagged for charge inhibit, timers are
 * started again and charging resumed.
 *
 * \retval ChargeParameters.NextState Next state once this stage is done.
 * If no errors occured, this will be whatever was set in Charge(). Otherwise,
 * HaltNow() will have set a new next state.
 */
unsigned char ConstantCurrent(void)
{
	unsigned char wasStopped = FALSE;
	
	// Wait for ADC conversions to complete.
	ADC_Wait();

	// If Master has flagged for a charge inhibit, pause charging.
	// (This is to prevent damage during prolonged serial communication.)
	if (BattControl[BattActive].ChargeInhibit) {
		wasStopped = TRUE;
		Time_Stop();
		OCR1B = 0;
	} else {
		// Continue charging!
		if (wasStopped) {
			wasStopped = FALSE;
			
			// Timer variables are not reset by this.
			Time_Start();
		}
         
		// Adjust the charge current to within ChargeParameters.Current
		// +/- BAT_CURRENT_HYST.
		if ((ADCS.avgIBAT < 0) ||
		    (ADCS.avgIBAT < (ChargeParameters.Current - BAT_CURRENT_HYST))) {
					 
			if(!PWM_IncrementDutyCycle()) {
#ifdef ABORT_IF_PWM_MAX
				// If the duty cycle cannot be incremented, flag error and
				// go to error state.
				SetErrorFlag(ERR_PWM_CONTROL);
				ChargeParameters.NextState = ST_ERROR;				
#endif
				}
			} else if ((ADCS.avgIBAT >= 0) &&
					(ADCS.avgIBAT > (ChargeParameters.Current + BAT_CURRENT_HYST))) {
					 
				if(!PWM_DecrementDutyCycle()) {
#ifdef ABORT_IF_PWM_MIN
					// If the duty cycle cannot be decremented, flag error and
					// go to error state.
					SetErrorFlag(ERR_PWM_CONTROL);
					ChargeParameters.NextState = ST_ERROR;
#endif
				}
			}
		}

	// Return the next state to Charge(). If an error has occured, this will
	// point to some other state than the next state of charging.
	return(ChargeParameters.NextState);
}


/*! \brief Charges battery with a constant voltage
 *
 * This function applies a constant voltage (set in ChargeParameters.Voltage)
 * to the battery until HaltNow() returns TRUE, or a PWM error occurs and
 * \ref ABORT_IF_PWM_MIN or \ref ABORT_IF_PWM_MAX is defined.\n
 * The charge voltage can vary with +/- \ref BAT_VOLTAGE_HYST.\n
 * If the Master inhibits charging, timers are stopped and PWM output dropped.
 * Once the battery is no longer flagged for charge inhibit, timers are
 * started again and charging resumed.
 *
 * \retval ChargeParameters.NextState Next state once this stage is done.
 * If no errors occured, this will be whatever was set in Charge(). Otherwise,
 * HaltNow() will have set a new next state.
 */
unsigned char ConstantVoltage(void)
{
	unsigned char wasStopped = FALSE;
			
	// Wait for ADC conversions to complete.
	ADC_Wait();
		
	// If Master has flagged for a charge inhibit, pause charging.
	// (This is to prevent damage during prolonged serial communication.)
	if (BattControl[BattActive].ChargeInhibit) {
		wasStopped = TRUE;
		Time_Stop();
		OCR1B = 0;
	}
	else {
		// Continue charging!
		if (wasStopped) {
			wasStopped = FALSE;
				
			// Timer variables aren't reset by this.
			Time_Start();
		}
			
		// Adjust the charge voltage to within ChargeParameters.Voltage
		// +/- BAT_VOLTAGE_HYST.
		if (ADCS.VBAT < (ChargeParameters.Voltage - BAT_VOLTAGE_HYST)) {

			if(!PWM_IncrementDutyCycle()) {
#ifdef ABORT_IF_PWM_MAX
				// Flag PWM control error and go to error-state if the duty
				// cycle cannot be incremented.
				SetErrorFlag(ERR_PWM_CONTROL);
				ChargeParameters.NextState = ST_ERROR;
#endif
			}
		} else if (ADCS.VBAT > (ChargeParameters.Voltage + BAT_VOLTAGE_HYST)) {

			if(!PWM_DecrementDutyCycle()) {
#ifdef ABORT_IF_PWM_MIN
				// Flag PWM control error and go to error-state if duty
				// cycle cannot be decremented.
				SetErrorFlag(ERR_PWM_CONTROL);
				ChargeParameters.NextState = ST_ERROR;
#endif
				}
			}
		}

	// Return the next state to Charge(). If an error has occured, this will
	// point to some other state than the next state of charging.
	return(ChargeParameters.NextState);
}


/*! \brief Determines when to halt charging.
 *
 * This function evaluates parameters depending on what has been flagged in
 * HaltParameters.HaltFlags, and returns TRUE or FALSE if the charging should
 * halt or not.\n
 * In addition, error flagging on timeout (battery exhaustion) can be set.\n
 *
 * The function also checks if the battery temperature is within limits,
 * if mains is OK, and if BatteryCheck() returns TRUE.
 * If an error is detected, the associated errorflag is set and 
 * ChargeParameters.NextState is changed to an appropriate state.
 *
 * \retval TRUE Halt now.
 * \retval FALSE Don't halt now.
 *
 * \note See chargefunc.h for definitions of halt flags.
 * \note It is generally a bad idea not to halt on a timeout.
 * \note If HALT_ON_VOLTAGE_DROP is set, HaltParameters.VBATMax should be
 * reset in Charge() before calling a charging-function.
 *
 * \todo "Priorities" of standard error checks OK?
 */
unsigned char HaltNow(void)
{
	unsigned char i, halt = FALSE;
	
	// Wait for a full ADC-cycle to finish.
	ADC_Wait();

	// Evaluate ADC readings according to HaltFlags. Flag errors if selected.
	// If an error is flagged, ChargeParameters.NextState is set to ST_ERROR.
	// (Gets overridden if either mains is failing, or the battery changes.)
	for (i = 0x01; i != 0; i <<= 1) {
		if (HaltParameters.HaltFlags & i) {
			switch (i) {
			// Is VBAT less than the recorded maximum?
			case HALT_VOLTAGE_DROP:

				// Update VBATMax if VBAT is higher. Evaluate for halt otherwise.
				if (ADCS.VBAT > HaltParameters.VBATMax) {
					HaltParameters.VBATMax = ADCS.VBAT;
				} else if((HaltParameters.VBATMax - ADCS.VBAT) >= 
				          HaltParameters.VoltageDrop) {
					halt = TRUE;
				}
			break;

			
			// Has VBAT reached the maximum limit?
			case HALT_VOLTAGE_MAX:  
				
				if (ADCS.VBAT >= HaltParameters.VoltageMax) {
					halt = TRUE;
				}
				break;


			// Has IBAT reached the minimum limit?
			case HALT_CURRENT_MIN:
				
				if (ADCS.avgIBAT <= HaltParameters.CurrentMin) {
					halt = TRUE;
				}
				break;
	
				
			// Is the temperature rising too fast?
			case HALT_TEMPERATURE_RISE:

				// If rawNTC has increased, the temperature has dropped.
				// We can store this value for now, and start the timer.
				// Otherwise, check if NTC has changed too fast.
				if (ADCS.rawNTC > HaltParameters.LastNTC) {
					HaltParameters.LastNTC = ADCS.rawNTC;
					Time_Set(TIMER_TEMP,0,30,0);
					
				// Is the increase in temperature greater than the set threshold?
				} else  if ((HaltParameters.LastNTC - ADCS.rawNTC) >=
				  (BattData.ADCSteps * HaltParameters.TemperatureRise)) {
					
					// If this happened within a timeframe of 30 seconds, the 
					// temperature is rising faster than we want.
					// If not, update LastNTC and reset timer.
					if (Time_Left(TIMER_TEMP))  {
						halt = TRUE;
					} else {
						HaltParameters.LastNTC = ADCS.rawNTC;
						Time_Set(TIMER_TEMP,0,30,0);
					}
				}
			break;
				
			// Is there any time left?
			case HALT_TIME:  
				
				if (!Time_Left(TIMER_CHG)) {
					halt = TRUE;
					
					// If exhaustion flagging is selected, stop the PWM, disable the 
					// battery and flag it as exhausted. Make ST_ERROR next state.
					if (HaltParameters.HaltFlags & HALT_FLAG_EXHAUSTION) {
							PWM_Stop();
							BattControl[BattActive].Enabled = FALSE;
							BattData.Exhausted = TRUE;
							SetErrorFlag(ERR_BATTERY_EXHAUSTED);
							ChargeParameters.NextState = ST_ERROR;
					}
				}
			break;		
			
			default:  // Shouldn't end up here, but is needed for MISRA compliance.
			break;
			}
		}
	}

	// Standard checks:

	// Battery too cold or hot?
	if ((BattData.Temperature <= HaltParameters.TemperatureMin) ||
	    (BattData.Temperature >= HaltParameters.TemperatureMax)) {
			
		PWM_Stop();
		SetErrorFlag(ERR_BATTERY_TEMPERATURE);
		ChargeParameters.NextState = ST_ERROR;
		halt = TRUE;
	}

	// Battery not OK?
	if (!BatteryCheck()) {
		PWM_Stop();
		ChargeParameters.NextState = ST_INIT;
		halt = TRUE;
	}

	// Is mains voltage OK?
	if (!ADCS.Mains) {
		PWM_Stop();
		ChargeParameters.NextState = ST_SLEEP;
		halt = TRUE;
	}
		
	return(halt);
}
