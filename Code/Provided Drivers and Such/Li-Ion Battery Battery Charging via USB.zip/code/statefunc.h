/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Headerfile for statefunc.c
 *
 *      Contains definitions for SPI mode and error identifiers.
 *
 * \par Application note:
 *      AVR458: Charging Li-Ion Batteries with BC100 \n
 *      AVR463: Charging NiMH Batteries with BC100
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler 
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 * 
 * $Name$
 * $Revision: 2335 $
 * $RCSfile$
 * $URL: http://svn.norway.atmel.com/AppsAVR8/avr458_Charging_Li-Ion_Batteries_with_BC100/trunk/code/IAR/statefunc.h $
 * $Date: 2007-09-07 10:11:19 +0200 (Fri, 07 Sep 2007) $\n
 ******************************************************************************/

#ifndef STATEFUNC_H
#define STATEFUNC_H


//******************************************************************************
// Wanted SPI-mode
//******************************************************************************
//! Sample on leading _rising_ edge, setup on trailing _falling_ edge.
#define SPIMODE 0

//! Sample on leading _falling_ edge, setup on trailing _rising_ edge.
//#define SPIMODE 1    


//******************************************************************************
// Typical and maximum voltage difference between supply and battery
//******************************************************************************
//! Typical difference between VIN and VBAT, in mV.
#define VIN_VBAT_DIFF_TYP     600

//! Maximum allowed difference between VIN - VIN_VBAT_DIFF_TYP and VBAT, in mV.
#define VIN_VBAT_DIFF_MAX     500


//******************************************************************************
// Error-flag bit identifiers
//******************************************************************************
//! Wrong jumper settings.
#define   ERR_JUMPER_MISMATCH				0x01  

//! Both batteries disabled.
#define   ERR_NO_BATTERIES_ENABLED		0x02  

//! PWM output too much/little.
#define   ERR_PWM_CONTROL					0x04  

//! Battery temperature out of limits.
#define   ERR_BATTERY_TEMPERATURE		0x08  

//! Battery couldn't be charged.
#define   ERR_BATTERY_EXHAUSTED			0x10  


//******************************************************************************
// Function prototypes
//******************************************************************************
unsigned char Initialize(unsigned char);
unsigned char BatteryControl(unsigned char);
unsigned char Discharge(unsigned char);
unsigned char Sleep(unsigned char);
unsigned char Error(unsigned char);
void SetErrorFlag(unsigned char);


#endif // STATEFUNC_H
