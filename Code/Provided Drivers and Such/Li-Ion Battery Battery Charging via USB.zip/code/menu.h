/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Headerfile for menu.c
 * 
 *      Contains definitions of each state and declaration of the state
 *      menu entry struct.
 *
 * \par Application note:
 *      AVR458: Charging Li-Ion Batteries with BC100 \n
 *      AVR463: Charging NiMH Batteries with BC100
 *
 * \par Documentation:
 *      For comprehensive code documentation, supported compilers, compiler
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 *
 * $Name$
 * $Revision: 2335 $
 * $RCSfile$
 * $URL: http://svn.norway.atmel.com/AppsAVR8/avr458_Charging_Li-Ion_Batteries_with_BC100/trunk/code/IAR/menu.h $
 * $Date: 2007-09-07 10:11:19 +0200 (Fri, 07 Sep 2007) $\n
 ******************************************************************************/

#ifndef MENU_H
#define MENU_H

//******************************************************************************
// State machine states
//******************************************************************************
// State machine states -- max size and number of states is 255.
// State values must be larger than zero
#define ST_INIT           (10)  //!< Identifies initialization state.
#define ST_BATCON         (20)  //!< Identifies battery control state.
#define ST_PREQUAL        (30)  //!< Identifies prequalification state.
#define ST_SLEEP          (40)  //!< Identifies sleep state.
#define ST_FASTCHARGE     (50)  //!< Identifies fast charge state.
#define ST_LOWRATECHARGE  (60)  //!< Identifies trickle charge state.
#define ST_ENDCHARGE		  (70)  //!< Identifies end of charge.
#define ST_DISCHARGE      (80)  //!< Identifies discharge state.
#define ST_ERROR          (90)  //!< Identifies error state.
#define ST_CCURRENT       (100)  //!< Identifies constant current charge state.
#define ST_CVOLTAGE       (110)  //!< Identifies constant voltage charge state.
#define ST_CCURRENT_CTRL  (120)	//added to suppress active waiting state
#define ST_PREQUAL_CTRL   (130)	//added to suppress active waiting state
#define ST_CVOLTAGE_CTRL  (140)	//added to suppress active waiting state

//******************************************************************************
// Struct declarations
//******************************************************************************
/*! \brief Holds an entry in the state menu
 *
 * Contains the ID number of a state, and a pointer to its associated function
 */
struct MENU_STATE_struct
{
  unsigned char state;	//!< ID number of state.
  unsigned char (*pFunc)(unsigned char inp);  //!< Associated function.
};
typedef struct MENU_STATE_struct MENU_STATE_t; //!< For convenience.


//******************************************************************************
// Global variables
//******************************************************************************
//extern __flash const MENU_STATE_t menu_state[];
extern const MENU_STATE_t menu_state[];

#endif // MENU_H
