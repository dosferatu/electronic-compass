/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Headerfile for main.c
 *
 *      Contains some basic definitions (FALSE, TRUE, ZERO) as well as
 *      what battery type (NiMh or Li-Ion) the charger is for.
 * 
 * \par Application note:
 *      AVR458: Charging Li-Ion Batteries with BC100 \n
 *      AVR463: Charging NiMH Batteries with BC100
 *
 * \par Documentation:
 *      For comprehensive code documentation, supported compilers, compiler
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 *
 * $Name$
 * $Revision: 2335 $
 * $RCSfile$
 * $URL: http://svn.norway.atmel.com/AppsAVR8/avr458_Charging_Li-Ion_Batteries_with_BC100/trunk/code/IAR/main.h $
 * $Date: 2007-09-07 10:11:19 +0200 (Fri, 07 Sep 2007) $\n
 ******************************************************************************/

#ifndef _MAIN_H
#define _MAIN_H


//******************************************************************************
// Firmware revision
//******************************************************************************
#define SWHIGH  1
#define SWLOW   0


//******************************************************************************
// Battery type (add appropriate *charge.c to project!)
//******************************************************************************
//#define NIMH  //!< Use specs and state menu for NIMH.
#define LIION  //!< Use specs and state menu for LIION.


//******************************************************************************
// Basic definitions
//******************************************************************************

#define ZERO    0  //!< We have to define this ourselves.


//******************************************************************************
// Global variables
//******************************************************************************
extern unsigned char CurrentState;


#endif //_MAIN_H
