/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Headerfile for chargefunc.c
 *
 *      Contains definitions to decide PWM error handling and of halt flags,
 *      and declarations of parameter structs for charging.
 *
 * \par Application note:
 *      AVR458: Charging Li-Ion Batteries with BC100 \n
 *      AVR463: Charging NiMH Batteries with BC100
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler 
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 * 
 * $Name$
 * $Revision: 2335 $
 * $RCSfile$
 * $URL: http://svn.norway.atmel.com/AppsAVR8/avr458_Charging_Li-Ion_Batteries_with_BC100/trunk/code/IAR/chargefunc.h $
 * $Date: 2007-09-07 10:11:19 +0200 (Fri, 07 Sep 2007) $\n
 ******************************************************************************/

#ifndef CHARGEFUNC_H
#define CHARGEFUNC_H


//******************************************************************************
// PWM error handling
//******************************************************************************
//! Report error if maximum duty cycle doesn't give a sufficient charge current.
//#define ABORT_IF_PWM_MAX

//! Report error if minimum duty cycle gives a too great charge current.
//#define ABORT_IF_PWM_MIN


//******************************************************************************
// Definitions for HaltFlags
//******************************************************************************
//! Halt if VBAT drops more than the set limit.
#define HALT_VOLTAGE_DROP		0x01  

//! Halt if VBAT reaches the set maximum.
#define HALT_VOLTAGE_MAX		0x02  

//! Halt if avgIBAT goes below the set minimum.
#define HALT_CURRENT_MIN		0x04  

//! Halt if BattData.Temperature rises quicker than the set maximum.
#define HALT_TEMPERATURE_RISE	0x08

//! Halt if TIMER_CHG runs out.
#define HALT_TIME					0x10  

//! Flag battery as exhausted if timeout occurs.
#define HALT_FLAG_EXHAUSTION	0x20


//******************************************************************************
// Parameter struct for charging
//******************************************************************************
/*! \brief Holds the parameters for ConstantCurrent() and ConstantVoltage().
 *
 */
struct ChargeParameters_struct {
	unsigned int Voltage;  //!< Voltage to charge with.
	unsigned int Current;  //!< Current to charge with.
	unsigned char NextState;  //!< \brief Next state once charge stage finishes.
	                         //!< \note Set in Charge(), but may be changed by
	                         //!< HaltNow() if an error occurs!
};
typedef struct ChargeParameters_struct ChargeParameters_t;


//******************************************************************************
// Parameter struct for HaltNow()
//******************************************************************************
/*! \brief Holds the parameters for HaltNow();
 *
 */
struct HaltParameters_struct {
	//! \brief Contains flags for what to evaluate. 
	//! \note See chargefunc.h for definitions of flags.
	unsigned char HaltFlags;
	
	//! Maximum drop in voltage before halting, in mV.
	unsigned int VoltageDrop;  
	
	//! Maximum limit for output voltage, in mV.
	unsigned int VoltageMax;  
	
	//! Minimum limit for output current, in mA.
	unsigned int CurrentMin;
	
	//! Maximum limit for battery temperature, in degrees centigrade.
	unsigned int TemperatureMax;
	
	//! Minimum limit for battery temperature, in degrees centigrade.
	signed int TemperatureMin;

	//! Maximum limit for temperature to rise, in degrees centigrade per minute.
	unsigned int TemperatureRise;

	//! \brief Contains highest VBAT measured, used to calculate voltage drop.
	//! \note Must be manually reset.
	unsigned int VBATMax;

	//! Used to detect temperature rise.
	unsigned int LastNTC;  
};
typedef struct HaltParameters_struct HaltParameters_t;


//******************************************************************************
// Global variables
//******************************************************************************
extern ChargeParameters_t ChargeParameters;
extern HaltParameters_t HaltParameters;


//******************************************************************************
// Function prototypes
//******************************************************************************
unsigned char ConstantCurrent(void);
unsigned char ConstantVoltage(void);
unsigned char HaltNow(void);

#endif // CHARGEFUNC_H
