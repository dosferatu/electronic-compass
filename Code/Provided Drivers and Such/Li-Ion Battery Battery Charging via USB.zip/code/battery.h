/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Headerfile for battery.c
 *
 *      Contains definitions for the setup of 1-Wire(R) and behaviour of the
 *      battery data and status refreshing functions.\n
 *      Also contains definitions of default battery data, and declarations
 *      for the RID and NTC lookup tables.
 *
 * \par Application note:
 *      AVR458: Charging Li-Ion Batteries with BC100 \n
 *      AVR463: Charging NiMH Batteries with BC100
 *
 * \par Documentation:
 *      For comprehensive code documentation, supported compilers, compiler
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com \n
 *      Original author: \n
 *
 * $Name$
 * $Revision: 2335 $
 * $RCSfile$
 * $URL: http://svn.norway.atmel.com/AppsAVR8/avr458_Charging_Li-Ion_Batteries_with_BC100/trunk/code/IAR/battery.h $
 * $Date: 2007-09-07 10:11:19 +0200 (Fri, 07 Sep 2007) $\n
 ******************************************************************************/


#ifndef BATTERY_H
#define BATTERY_H



#ifdef __GNUC__
   #include <avr/eeprom.h>
#endif

//******************************************************************************
// RID-less charging (for BatteryStatusRefresh())
//******************************************************************************
//#define ALLOW_NO_RID  //!< Use default battery data if no matching entry found.

#define DEF_BAT_CAPACITY		0  //!< Default battery capacity, in mAh.
#define DEF_BAT_CURRENT_MAX	0  //!< Default maximum charge current, in mA.
#define DEF_BAT_TIME_MAX		0  //!< Default maximum charge time, in minutes.
//! Default minimum current to stop charge, in mA.
#define DEF_BAT_CURRENT_MIN	0

//******************************************************************************
// RID and NTC defines and struct declarations
//******************************************************************************
#define RID_TABLE_SIZE        4     //!< Number of entries in RID table.
#define NTC_TABLE_SIZE        20    //!< Number of entries in NTC table.

//! \brief Struct for an entry in the resistor ID lookup-table
struct RID_Lookup_struct {
  unsigned int  Low;              //!< Lowest acceptable ADC value.
  unsigned int  High;             //!< Highest acceptable ADC value.
  unsigned int  Resistance;       //!< RID resistance, in Ohms.
  unsigned int  Capacity;         //!< Associated battery capacity, in mAh.
  unsigned int  Icharge;          //!< Associated initial charge current, in mA.
  unsigned int  tCutOff;          //!< Associated cut-off time, in minutes.
  unsigned int  ICutOff;          //!< Associated cut-off current, in mA.
};
typedef struct RID_Lookup_struct RID_Lookup_t; //!< For convenience.

/*! \brief Struct for an entry in the NTC lookup-table
 *
 * \note Must be sorted in descending ADC order.
 */

struct NTC_Lookup_struct {
  unsigned int TADC;  //!< Measured NTC.
  unsigned char ADCsteps;  //!< ADC steps per half degree at this temperature.
};
typedef struct NTC_Lookup_struct NTC_Lookup_t; //!< For convenience.


//******************************************************************************
// Global variables
//******************************************************************************

#ifdef __GNUC__
   extern EEMEM Battery_t BattControl[];
#elif __ICCAVR__
   extern __eeprom Battery_t BattControl[];
#else
   #error Current COMPILER not supported
#endif

extern Batteries_t BattData;


#ifdef __GNUC__
   extern EEMEM unsigned char BattEEPROM[][32];
#elif __ICCAVR__
   extern __eeprom unsigned char BattEEPROM[][32];
#else
   #error Current COMPILER not supported
#endif

extern unsigned char BattActive;


//******************************************************************************
// Function prototypes
//******************************************************************************
unsigned char BatteryCheck(void);
unsigned char BatteryStatusRefresh(void);
unsigned char BatteryDataRefresh(void);
unsigned char RIDLookUp(void);
void NTCLookUp(void);


#endif // BATTERY_H
