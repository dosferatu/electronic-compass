
/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Main program file
 *
 *      Contains the main program, which is a basic state machine.
 *
 * \par Application note:
 *      AVRxxx: Lithium-Ion battery charging via USB with ATMega32U4  \n
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler 
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 * 
 * $Name$
 * $Revision: $
 * $RCSfile$
 * $URL: $
 * $Date: $\n
 ******************************************************************************/

/*! \page License
 * Copyright (c) 2007, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include <stdlib.h>
#include <stdio.h>

#include "structs.h"
#include "modules/usb/device_chap9/usb_standard_request.h"
#include "main.h"
#include "lib_mcu/pwm/pwm.h"
#include "lib_mcu/adc/adc.h"

#include "statefunc.h"
#include "battery.h"
#include "menu.h"
#include "usb_specific_request.h"

/*****************************************************************************/
/*                             VT100 Commands                                */
/*****************************************************************************/

#define CLEARSCR        "\x1B[2J\x1B[;H"        // Clear SCReen
#define CLEAREOL        "\x1B[K"                // Clear End Of Line
#define CLEAREOS        "\x1B[J"                // Clear End Of Screen
#define CLEARLCR        "\x1B[0K"               // Clear Line Cursor Right
#define CLEARLCL        "\x1B[1K"               // Clear Line Cursor Left
#define CLEARELN        "\x1B[2K"               // Clear Entire LiNe
#define CLEARCDW        "\x1B[0J"               // Clear Curseur DoWn
#define CLEARCUP        "\x1B[1J"               // Clear Curseur UP
#define GOTOYX          "\x1B[%.2d;%.2dH"       // Goto at (y,x)

#define INSERTMOD       "\x1B[4h"               // Mode insertion
#define OVERWRITEMOD    "\x1B[4l"               // Mode de non insertion
#define DELAFCURSOR     "\x1B[K"
#define CRLF            "\r\n"                  // Retour � la ligne

/* VT100 : Actions sur le curseur */
#define CURSON          "\x1B[?25h"             // Curseur visible
#define CURSOFF         "\x1B[?25l"             // Curseur invisible

/* VT100 : Actions sur les caract�res affichables */
#define NORMAL          "\x1B[0m"               // Normal
#define BOLD            "\x1B[1m"               // Gras
#define UNDERLINE       "\x1B[4m"               // Soulign�
#define BLINKING        "\x1B[5m"               // Clignotant
#define INVVIDEO        "\x1B[7m"               // Inverse vid�o

/* VT100 : Couleurs */
#define CL_BLACK "\033[22;30m"			// Noir
#define CL_RED "\033[22;31m"			// Rouge
#define CL_GREEN "\033[22;32m"			// Vert
#define CL_BROWN "\033[22;33m"		// Brun
#define CL_BLUE "\033[22;34m"			// Bleu
#define CL_MAGENTA "\033[22;35m"		// Magenta
#define CL_CYAN "\033[22;36m"			// Cyan
#define CL_GRAY "\033[22;37m"			// Gris
#define CL_DARKGRAY "\033[01;30m"		// Gris fonc�
#define CL_LIGHTRED "\033[01;31m"		// Rouge clair
#define CL_LIGHTGREEN "\033[01;32m"	// Vert clair
#define CL_YELLOW "\033[01;33m"		// Jaune
#define CL_LIGHTBLUE "\033[01;34m"		// Bleu clair
#define CL_LIGHTMAGENTA "\033[01;35m"	// Magenta clair
#define CL_LIGHTCYAN "\033[01;36m"		// Cyan clair
#define CL_WHITE "\033[01;37m"			// Blanc

//******************************************************************************
// Globals
//******************************************************************************
unsigned char CurrentState;     //!< \brief Global that indicates current state
                                //!<
                                //!< Updated by main().
                                //!< \note See menu.h for definition of states.


unsigned char nextstate, inp;
unsigned char (*pStateFunc)(unsigned char);   // Function pointer.

unsigned char printer_state;
unsigned int loop_counter;
unsigned int loop_counter_max;
unsigned char return_state;
unsigned char old_batt_present;

extern const RID_Lookup_t RID[RID_TABLE_SIZE];

extern S_line_status line_status;

//! @brief This function initializes the hardware ressources required for CDC demo.
//!
//!
//! @param none
//!
//! @return none
//!
//!/
void batt_task_init(void)
{
	unsigned char i;

	ADC_Init();

	//init state machine
	printer_state = '1';	
	old_batt_present = FALSE;

 	// Initialize local state variables.
	inp = ZERO;
	CurrentState = nextstate = ST_INIT;

	pStateFunc = NULL;
	
	ADCS.Mains = 1;

	// Look for function associated with current state, get its address.
	for (i = 0; menu_state[i].state != 0; i++) {
		if (menu_state[i].state == CurrentState) {
			pStateFunc = menu_state[i].pFunc;
		}
	}
}

//******************************************************************************
// Functions
//******************************************************************************
/*! \brief Main program
 *
 * The main function goes into an infinite loop, keeping track of the current
 * state and the next one. If the next state is different from the current, it
 * looks up the address to the next state function, in \ref menu_state[], and 
 * updates \ref CurrentState. The state function is then called and will
 * eventually return a new state, and so the loop reiterates.
 *
 * \todo The variable inp is passed to all state functions, but is not used
 * for anything yet. Remove?
 */
void batt_task(void)
{
	unsigned char i;
	int charge_status;
	
	if(Is_device_enumerated()){ //Enumeration processs OK ?
	  	
	  	//refresh display if battery movement
		if(old_batt_present != BattData.Present)
			printer_state = '1';
	  
		old_batt_present = BattData.Present;
 
		//Enumeration processs OK and COM port openned ?
		if((Is_device_enumerated() && line_status.DTR))
		{
			if(BattData.Present){		  
				switch(printer_state) {
					case '1':	
          				printf(CLEARSCR);			  
			  			//go to waiting loop
			        	loop_counter = 0;
			  			return_state = '2';
						printer_state = '7';
					break;
		
					case '2':
				  		for(i=0;i<RID_TABLE_SIZE;i++)
						{
				  			if( (ADCS.rawRID >= RID[i].Low) && (ADCS.rawRID <= RID[i].High))
							{
								switch(i) {
						  			case 0:				  
	  									printf("BATTERY: VARTA EASY PACK 550mA \r\n\n");
									break;	
							
						  			case 1:				  
	  									printf("BATTERY: VARTA EASY PACK 750mA \r\n\n");
									break;	
								
						  			case 2:				  
	  									printf("BATTERY: VARTA EASY PACK 1000mA \r\n\n");
									break;
							
						  			case 3:				  
	  									printf("BATTERY: VARTA EASY PACK 2000mA \r\n\n");
									break;
							
									default:  
	  									printf("BATTERY: RID NOT IN TABLE \r\n\n");							  
									break;
								} 
							}
						}
						    						
			  			//go to waiting loop
			  			return_state = '3';
						printer_state = '7';
					break;
		
					case '3':		
	  					//printf("Battery voltage = %d !\r\n",ADCS.VBAT);
			 			printf("Battery voltage (mV) = ");
						printf(CL_RED);
						printf("%d \r\n",ADCS.VBAT);
						printf(CL_BLACK);
			  			//go to waiting loop
			  			return_state = '4';
						printer_state = '7';
					break;	

					case '4':			
          				printf("Battery current (mA) = ");
						printf(CL_RED);
						printf("%d \r\n",ADCS.avgIBAT);
						printf(CL_BLACK);				
			  			//go to waiting loop
			  			return_state = '5';
						printer_state = '7';
					break;
		
					case '5':			
          				printf("Battery temperature (C) = ");
						printf(CL_RED);
						printf("%d \r\n",BattData.Temperature);
						printf(CL_BLACK);					
			  			//go to waiting loop
			  			return_state = '6';
						printer_state = '7';
					break;		

					case '6':			
			  			switch (CurrentState)	{
			  				case ST_PREQUAL:
			  				case ST_PREQUAL_CTRL:
			  				case ST_CCURRENT:
			  				case ST_CCURRENT_CTRL:			    
	  							printf("Charging stage = ");
								printf(CL_RED);
								printf("Constant Current charge\r\n");
								printf(CL_BLACK);	
							break;
				
							case ST_CVOLTAGE:
			  				case ST_CVOLTAGE_CTRL:				  
	  							printf("Charging stage = ");
								printf(CL_RED);
								printf("Constant Voltage charge\r\n");
								printf(CL_BLACK);							
							break;	
				
							default:  // no charging
	  							printf("Charging stage = ");
								printf(CL_RED);
								printf("No charge\r\n");
								printf(CL_BLACK);							
							break;
						}

	  					printf("State of Charge = ");					  
						printf(CL_RED);
					
						if(CurrentState == ST_CVOLTAGE_CTRL)
						{					  
							for(i=0;i<RID_TABLE_SIZE;i++)
							{
				  				if( (ADCS.rawRID >= RID[i].Low) && (ADCS.rawRID <= RID[i].High))
								{
							  		//calculation of the SOC in %
									if(ADCS.avgIBAT > RID[i].Icharge)
									{
										//just at the beginning of CV charge, the current can be over RID[i].Icharge  
										charge_status = 0;
									}
									else
									{
										//display of SOC between Icharge and ICutOff
										charge_status = (100*(ADCS.avgIBAT));
										charge_status = charge_status / (RID[i].Icharge - RID[i].ICutOff);
										charge_status = (100*RID[i].Icharge) / (RID[i].Icharge - RID[i].ICutOff) - charge_status;
									}
									
									printf("%d %% (full charge = 100%%) \r\n", charge_status);
									printf(CL_BLACK);
								}
							}
						}
						else
						{
							printf(" not applicable \r\n");
							printf(CL_BLACK);				
						}
			  			//go to waiting loop
			  			return_state = '1';
						printer_state = '7';
						loop_counter_max = 500;				
					break;				
			
					case '7':
						//waiting loop
			  			if(loop_counter == loop_counter_max){
							loop_counter_max = 0;
				 	 		printer_state = return_state;
				 	 		loop_counter = 0;
						}
						else
				  			loop_counter++;
					break;
					default:
					break;
				}
			}
			//NO BATT
			else{
				switch(printer_state) {
					case '1':	
          				printf(CLEARSCR);
						printer_state = '2';
					break;

					case '2':
						printf("NO BATTERY DETECTED\r\n\n");			
						printer_state = '3';
						loop_counter_max = 20;		
					break; 
			
					case '3':
						//waiting loop
						if(loop_counter == loop_counter_max){
			 	 			printer_state = '1';
			 	 			loop_counter = 0;
						}
						else
			  				loop_counter++;
					break;
			
					default:
					break;			
				}//end switch
			}
		}
			  
		//wait a complete ADC conversion to update batt measurements
		ADC_Wait();
		 		
		// Run function associated with current state, get next state in return.
		if (pStateFunc != NULL){
			nextstate = pStateFunc(inp);
		}

		// Look up function for next state, if it differs from the current.
		if (nextstate != CurrentState) {
			CurrentState = nextstate;
			
			for ( i = 0; menu_state[i].state != 0; i++) {
				if (menu_state[i].state == CurrentState) {
					pStateFunc = menu_state[i].pFunc;
				}			
			}				
		}			
	}	
	else
	{
		//if USB cable is removed during charging
	  	PWM_Stop();
		pStateFunc = menu_state[0].pFunc;;
	}
}

