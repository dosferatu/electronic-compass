/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Structs in common for Slave and Master
 *
 *      Contains struct declarations for ADC.c and battery.c.\n
 *      These are also used in the Master, and have therefore been
 *      put in a separate file for convenience.
 *
 * \par Application note:
 *      AVR458: Charging Li-Ion Batteries with BC100 \n
 *      AVR463: Charging NiMH Batteries with BC100
 *
 * \par Documentation:
 *      For comprehensive code documentation, supported compilers, compiler
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com \n
 *
 * $Name$
 * $Revision: 2335 $
 * $RCSfile$
 * $URL: http://svn.norway.atmel.com/AppsAVR8/avr458_Charging_Li-Ion_Batteries_with_BC100/trunk/code/IAR/structs.h $
 * $Date: 2007-09-07 10:11:19 +0200 (Fri, 07 Sep 2007) $\n
 ******************************************************************************/


#ifndef STRUCTS_H
#define STRUCTS_H


//******************************************************************************
// Battery struct declarations
//******************************************************************************
/*! \brief Holds status and various data for a battery
 *
 * These data are updated by BatteryStatusRefresh(), RIDLookUp(),
 * NTCLookUp() and BatteryDataRefresh().
 */
struct Batteries_struct
{
	unsigned char Present   : 1; //!< Battery found. (TRUE/FALSE)
	unsigned char Charged   : 1; //!< Battery fully charged. (TRUE/FALSE)
	unsigned char Low       : 1; //!< Battery low voltage. (TRUE/FALSE)
	unsigned char Exhausted : 1; //!< Battery exhausted. (TRUE/FALSE)
	unsigned char HasRID		: 1; //!< Battery has resistor ID. (TRUE/FALSE)
	unsigned char Circuit;       //!< Battery safety circuit (family id).
	signed char Temperature;     //!< Battery temperature, in centigrade.
	unsigned char ADCSteps;      //!< ADC steps per half degree.
	unsigned int  Capacity;      //!< Capacity, in mAh.
	unsigned int  MaxCurrent;    //!< Charge current, in mA.
	unsigned int  MaxTime;       //!< Charge cut-off time, in minutes.
	unsigned int  MinCurrent;    //!< Cut-off current, in mA.
};
typedef struct Batteries_struct Batteries_t; //!< For convenience.


//! \brief Holds control data for a battery
struct Battery_struct
{
	//! Battery valid, enabling allowed. (TRUE/FALSE)
	unsigned char Enabled           : 1;
	
	//! Disconnect allowed. (TRUE/FALSE)
	unsigned char DisconnectAllowed : 1;
	
	//! Inhibit charging. (TRUE/FALSE) \todo Changed by master?
	unsigned char ChargeInhibit     : 1;
};
typedef struct Battery_struct Battery_t; //!< For convenience.

//******************************************************************************
// ADC status struct declaration
//******************************************************************************
/*! \brief Holds ADC-status and samples
 *
 * Is updated by ADC_ISR().
 */
struct ADC_Status_struct
{
	unsigned char MUX : 5;  //!< Corresponds to ADMUX low bits MUX4..0.
	unsigned char Flag : 1;  //!< ADC cycle complete (TRUE/FALSE).
	unsigned char Mains : 1;  //!< Mains OK? (TRUE/FALSE).
	unsigned char Halt : 1;  //!< Stop A/D-conversions (TRUE/FALSE).
	unsigned char ADC3_G20_OS : 4;  //!< Offset on ADC3 at 20x gain.
	unsigned char ADC5_G20_OS : 4;  //!< Offset on ADC5 at 20x gain.
	unsigned int rawRID;  //!< Raw, unconditioned resistor ID data.
	unsigned int rawNTC;  //!< Raw, unconditioned thermistor data.
	unsigned int rawVBAT;  //!< Raw, unconditioned battery voltage.
	unsigned int VIN;  //!< Supply voltage, in mV.
	unsigned int VBAT;  //!< Battery voltage, in mV.
	signed int IBAT;  //!< Battery current, in mA.
	signed int discIBAT[4];  //!< Discrete battery current readings, in mA.
	signed int avgIBAT;  //!< Average of the last four IBAT readings, in mA.
};
typedef struct ADC_Status_struct ADC_Status_t; //!< For convenience.


#endif // STRUCTS_H
