/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Headerfile for NIMHcharge.c and LIIONcharge.c
 *
 *      Contains definitions and declarations related to the charge state.
 *
 * \par Application note:
 *      AVR458: Charging Li-Ion Batteries with BC100 \n
 *      AVR463: Charging NiMH Batteries with BC100
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler 
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 * 
 * $Name$
 * $Revision: 2335 $
 * $RCSfile$
 * $URL: http://svn.norway.atmel.com/AppsAVR8/avr458_Charging_Li-Ion_Batteries_with_BC100/trunk/code/IAR/charge.h $
 * $Date: 2007-09-07 10:11:19 +0200 (Fri, 07 Sep 2007) $\n
 ******************************************************************************/

#ifndef CHARGE_H
#define CHARGE_H


//******************************************************************************
// Function prototypes
//******************************************************************************
unsigned char Charge(unsigned char inp);


#endif // CHARGE_H
