/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      State functions
 *
 *      Contains the functions related to the states defined in menu.h.\n
 *      Also contains related functions, i.e. for checking jumpers, setting
 *      error flags and "dozing".
 *
 *      \note The state function Charge() is in a separate file since it
 *      should easily be changed with regard to battery type.
 *
 * \par Application note:
 *      AVRxxx: Lithium-Ion battery charging via USB with ATMega32U4  \n
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler 
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 * 
 * $Name$
 * $Revision:$
 * $RCSfile$
 * $URL:$
 * $Date:$\n
 ******************************************************************************/
#include "config.h"
#include <stdlib.h>

#include "structs.h"
#include "enums.h"

#ifdef __GNUC__
   #include "lib_mcu/adc/adc.h"
   #include "lib_mcu/pwm/pwm.h"
   #include "lib_mcu/timer/time.h"
#elif __ICCAVR__
   #include "adc.h" 
   #include "PWM.h"
   #include "time.h"
#else
   #error Current COMPILER not supported
#endif


#include "statefunc.h"
#include "battery.h"
#include "charge.h"
#include "main.h"
#include "menu.h"


//******************************************************************************
// Variables
//******************************************************************************
unsigned char ErrorFlags;  //!< \brief Holds error flags.
                           //!< \note See statefunc.h for definitions of flags.

//! \brief Holds the state in which latest error flag was set.
//! \note See menu.h for definitions of states.
unsigned char ErrorState;


//******************************************************************************
// Functions
//******************************************************************************
/*! \brief Initialization
 *
 * - Sets the system clock prescaler to 1 (run at 8 MHz)
 * - Initializes the one-wire interface
 * - Clears on-chip EEPROM
 * - Sets battery enable pins as outputs, then disables batteries
 * - Initializes SPI according to \ref SPIMODE
 * - Initializes ADC
 * - Initializes timers
 * - Reads battery data from both battery inputs (via ADC)
 * - Disables batteries again
 * - Sets battery A as the current one (\ref BattActive = 0)
 * - Clears ErrorFlags
 *
 * \param inp Not used.
 *
 * \retval ST_BATCON Next state in the sequence.
 */
unsigned char Initialize(unsigned char inp)
{
//	unsigned char i, page;

	// Disable interrupts while setting prescaler.
	
#ifdef __GNUC__
	Disable_interrupt();
#else
	__disable_interrupt();
#endif	
	
//bug in xml file with CLKPCE mask
//	CLKPR = (1<<CLKPCE);          // Enable CLKPS bit modification.
	CLKPR = 0x80;
	CLKPR = 0;                    // Set prescaler 1 => 8 MHz clock frequency.
	
	//to update if needed
	// Clear on-chip EEPROM.
//	for (page = 0; page < 4; page++)	{
//		for (i = 0; i < 32; i++) {
//			BattEEPROM[page][i] = 0;
//		}
//	}
	
	Time_Init();

	// Attempt to get ADC-readings (also gets RID-data) from battery.
	ADC_Wait();
	BatteryStatusRefresh();
	
	BattActive = 0;               // We have to start somewhere..
	ErrorFlags = 0;
	
	// Init complete! Go to ST_BATCON next.
	return(ST_BATCON);
}


/*! \brief Tests jumper settings and batteries, starts charging if necessary.
 *
 * First, JumperCheck() is called. If successful, the function checks if any
 * valid batteries are connected and attempts to charge these, if necessary.\n
 * If no charging is necessary, the charger goes to ST_SLEEP next.\n
 * ST_ERROR is next if either JumperCheck() fails or there are no valid
 * batteries. In this last case, the error is also flagged.
 *
 * \param inp Not used.
 *
 * \retval ST_ERROR Next state if either the jumper check failed, or there are
 * no valid batteries.
 * \retval ST_PREQUAL Next state if a battery is found to enabled and not fully
 * charged.
 * \retval ST_SLEEP Next state if battery/batteries are enabled and fully
 * charged.
 */
unsigned char BatteryControl(unsigned char inp)
{
	//refresh ADC parameters
	ADC_Wait();

	if (BatteryStatusRefresh()) {
		if (!BattData.Charged) {
			BatteryDataRefresh();
				return(ST_PREQUAL);       
		}
	}

	// If we end up here, BATT fully charged.	

	return(ST_SLEEP);
}


/*! \brief Start running on batteries
 *
 * \todo Run on batteries, if battery voltage high enough.
 * \todo Jump here when mains voltage drops below threshold
 *
 */
unsigned char Discharge(unsigned char inp)
{
	return(ST_BATCON);  // Supply voltage restored, start charging
}


/*! \brief Sleeps until either battery needs charging
 *
 * Calls Doze(), then refreshes the status for both batteries on wakeup. If
 * connected batteries are both charged, the function will loop. If not, it's
 * back to ST_BATCON.
 *
 * \param inp Not used.
 *
 * \retval ST_BATCON Next state if a connected battery isn't fully charged.
 */
unsigned char Sleep(unsigned char inp)
{
	if ((BatteryStatusRefresh()) && (!BattData.Charged))
		return(ST_BATCON);
	else
	  	return(ST_SLEEP);
}

/*! \brief Handles errors
 *
 * Stops PWM output and disables batteries. The function then goes into a loop
 * that starts with a call to Doze(), then attempts to handle each error. The
 * loop will reiterate until all flags are cleared.\n
 * The charger will reinitialize after this.
 *
 * Jumper errors are handled by clearing the flag, then calling JumperCheck().
 * If unsuccessful, the error flag will now have been set again.\n
 *
 * If there are no valid batteries, the loop will simply reiterate until a
 * valid battery is found. The error flag will then be cleared.\n
 *
 * In the case of PWM controller or battery temperature errors, the error
 * flag is simply cleared. This is because the problem may have gone away during
 * Doze(), or after reinitializing.\n
 *
 * If a battery is exhausted, we clear its exhausted-flag in \ref BattData,
 * and change batteries before clearing the error flag.
 *
 * \param inp Not used.
 */
unsigned char Error(unsigned char inp)
{
	PWM_Stop();           // Stop charging.
	
	return(ST_INIT);
}


/*! \brief Sets the specified error-flag and saves the current state
 *
 * Updates \ref ErrorFlags and \ref ErrorState.
 *
 * \note Error flags are specified in statefunc.h.
 *
 * \param Flag Specifies what error to flag.
 */
void SetErrorFlag(unsigned char Flag)
{
	ErrorFlags |= Flag;
	ErrorState = CurrentState;
}

