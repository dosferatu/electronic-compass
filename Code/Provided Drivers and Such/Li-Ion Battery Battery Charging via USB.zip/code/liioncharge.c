/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Charge state function for Li-Ion batteries
 *
 *      Contains the charge state function, in which the Li-Ion charging
 *      algorithm is, plus the associated functions.
 *
 *      AVRxxx: Lithium-Ion battery charging via USB with ATMega32U4  \n
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler 
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 * 
 * $Name$
 * $Revision:$
 * $RCSfile$
 * $URL:$
 * $Date:$\n
 ******************************************************************************/
#include "config.h"
#include "enums.h"
#include "structs.h"

#include "battery.h"
#include "charge.h"
#include "chargefunc.h"
#include "main.h"
#include "menu.h"
#include "LIIONspecs.h"

#ifdef __GNUC__
   #include "lib_mcu/pwm/pwm.h"
   #include "lib_mcu/timer/time.h"
#elif __ICCAVR__
   #include "PWM.h"
   #include "time.h"
#else
   #error Current COMPILER not supported
#endif


#ifndef LIION
#error LIION not defined in main.h!
#endif // LIION


//******************************************************************************
// Functions
//******************************************************************************
/*! \brief Controls the charging.
 *
 * This function contains the charging algorithm itself, divided into stages.\n
 * For each stage the PWM may be started/stopped, and the timer, 
 * halt-requirements and charge parameters may be set.\n
 * The charging functions return whatever state is next, and as long as no
 * errors occur this is the next charging stage.
 *
 * \note If more stages are needed simply define more states in menu.h, include
 * them in \ref menu_state[] in menu.c, then add the cases to this function.
 *
 * \note This algorithm is for Li-Ion batteries.
 */
unsigned char Charge(unsigned char inp)
{
	unsigned char NextState;

	switch (CurrentState)	{
	case ST_PREQUAL:  // First step is prequalification.
		
		// Charge with the defined prequalifiction-current, and if no errors
		// occur return ST_CCURRENT as the next state.
		ChargeParameters.Current = BAT_CURRENT_PREQUAL;
		ChargeParameters.NextState = ST_CCURRENT;
		
		// We want charging to halt if voltage reaches a limit or time runs out.
		// In case of timeout the battery will be flagged as exhausted, and an
		// error will be flagged.
		HaltParameters.HaltFlags = (HALT_VOLTAGE_MAX | HALT_TIME | 
		                            HALT_FLAG_EXHAUSTION);
		
		// Set the maximum temperature and charge voltage limit.
		HaltParameters.TemperatureMax = BAT_TEMPERATURE_MAX;
		HaltParameters.TemperatureMin = BAT_TEMPERATURE_MIN;
		HaltParameters.VoltageMax = BAT_VOLTAGE_PREQUAL;

		// Start PWM output and charging timer first.	
		PWM_Start();
	
		Time_Set(TIMER_CHG, BAT_TIME_PREQUAL, 0, 0);

		// Call the constant current charging-function.
		// If all goes well, we will get ST_CCURRENT in return.
		NextState = ST_PREQUAL_CTRL;		
	break;
	
	case ST_PREQUAL_CTRL:
 		ChargeParameters.NextState = ST_CCURRENT;	
		NextState = ST_CCURRENT;
		
		if ((HaltNow()!=TRUE)&&(ConstantCurrent() != ST_ERROR))
		{
  			ChargeParameters.NextState = ST_PREQUAL_CTRL;			
			NextState = ST_PREQUAL_CTRL;
		}
	break;

	case ST_CCURRENT:  // Second step is constant current charging.
		
		// Set charging timer to the battery's maximum charge time.
		Time_Set(TIMER_CHG,BattData.MaxTime,0,0);

		// Charge at the battery's maximum current, go to ST_CVOLTAGE next.
		ChargeParameters.Current = BattData.MaxCurrent;
		ChargeParameters.NextState = ST_CVOLTAGE;


		// Charge until the defined BatChargeVoltage is reached.
		HaltParameters.VoltageMax = BAT_VOLTAGE_MAX;
		
		// Start charging using constant current.
		NextState = ST_CCURRENT_CTRL;
	break;
	
	case ST_CCURRENT_CTRL: 
  		ChargeParameters.NextState = ST_CVOLTAGE;
		NextState = ST_CVOLTAGE;		
		
		if ((HaltNow()!=TRUE)&&(ConstantCurrent() != ST_ERROR))
		{
  			ChargeParameters.NextState = ST_CCURRENT_CTRL;	
			NextState = ST_CCURRENT_CTRL;	
		}
					
	break;

	case ST_CVOLTAGE:  // Third step is constant voltage charging.
		
		// Charge with the defined charge-voltage, go to ST_ENDCHARGE next.
		ChargeParameters.Voltage = BAT_VOLTAGE_MAX;
		ChargeParameters.NextState = ST_ENDCHARGE;
		
		// We want charging to halt if temperature rises too high, if current
		// sinks below limit, or time runs out. Also, flag error if temperature
		// limit is reached. Timeout doesn't mean anything is wrong at this point.
		HaltParameters.HaltFlags = (HALT_CURRENT_MIN | HALT_TIME);
		
		HaltParameters.CurrentMin = BattData.MinCurrent;
		
		// Start charging using constant voltage. We will continue on the 
		// timer started in ST_CCURRENT.
		NextState = ST_CVOLTAGE_CTRL;		
	break;

	case ST_CVOLTAGE_CTRL: 
  		ChargeParameters.NextState = ST_ENDCHARGE;
		NextState = ST_ENDCHARGE;		
		
		if ((HaltNow()!=TRUE)&&(ConstantVoltage() != ST_ERROR))
		{
  			ChargeParameters.NextState = ST_CVOLTAGE_CTRL;	
			NextState = ST_CVOLTAGE_CTRL;	
		}
					
	break;	

	case ST_ENDCHARGE:  // Charging is done!

		PWM_Stop();
		BattData.Charged = TRUE;
		
		NextState = ST_SLEEP;
		
	break;


	default:  // Shouldn't end up here. Reinitialize for safety.
		NextState = ST_INIT;
		break;
	}

	// Return the next state.
	return(NextState);
}
