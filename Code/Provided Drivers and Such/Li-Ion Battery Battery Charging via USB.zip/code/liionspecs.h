/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Li-Ion specifications
 *
 *      Contains example definitions of Li-Ion battery specifications.
 *
 * \par Application note:
 *      AVR458: Charging Li-Ion Batteries with BC100
 *
 * \par Documentation:
 *      For comprehensive code documentation, supported compilers, compiler
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com \n
 *      Original author: \n
 *
 * $Name$
 * $Revision: 2261 $
 * $RCSfile$
 * $URL: http://svn.norway.atmel.com/AppsAVR8/avr458_Charging_Li-Ion_Batteries_with_BC100/trunk/code/IAR/LIIONspecs.h $
 * $Date: 2007-08-10 09:28:35 +0200 (Fri, 10 Aug 2007) $\n
 ******************************************************************************/

#ifndef LIIONSPECS_H
#define LIIONSPECS_H


//******************************************************************************
// Cell limits
//******************************************************************************
// This is for common NiMH batteries.
#define	CELL_VOLTAGE_SAFETY	0  /*!< \brief Buffer for unmatched batteries.
 * 
 * If we are charging a multicell battery and the cells aren't matched, we
 * may risk overcharging at least one. Therefore, we may subtract this constant
 * per additional cell in battery to allow for a "buffer".
 *
 * \note Set to 0 if batteries are properly matched.
 *
 * \note If this is changed to something higher than (CELL_VOLTAGE_MAX -
 * CELL_VOLTAGE_LOW), and the number of cells is great enough, the limit
 * BAT_VOLTAGE_LOW will become higher than BAT_VOLTAGE_MAX. This will cause
 * the charger to keep trying to charge, but instantly finishing because
 * the battery voltage is already at max.
 */
//! Maximum charge voltage for cell, in mV.
#define	CELL_VOLTAGE_MAX     4200

//! Minimum voltage to consider cell charged at, in mV.
#define	CELL_VOLTAGE_LOW     4050 

//! Minimum voltage to start charging at, in mV.
#define	CELL_VOLTAGE_MIN     2750

//! Target voltage during prequalification, in mV.
#define	CELL_VOLTAGE_PREQUAL 3000

//******************************************************************************
// Battery limits
//******************************************************************************
// Battery-definitions.
//! Number of cells in battery.
#define	BAT_CELL_NUMBER      1

//! Maximum cell temperature (Celsius).
#define	BAT_TEMPERATURE_MAX  45

//! Minimum Cell temperature (Celsius).
#define BAT_TEMPERATURE_MIN   0

//! Maximum time for prequalification, in minutes.
#define	BAT_TIME_PREQUAL     9

//! \brief Constant charge current, in mA, during prequalification mode.
//! \note This is typically lower than the main charge current.
#define	BAT_CURRENT_PREQUAL  150

//number of scheduler loop before to check current
#define BAT_CC_LOOP     10

//! Charge current hysteresis, in mA.
#define	BAT_CURRENT_HYST     5 

//! Charge voltage hysteresis, in mV.
#define	BAT_VOLTAGE_HYST     10

//! Maximum battery voltage, in mV. 
#define	BAT_VOLTAGE_MAX      (CELL_VOLTAGE_MAX * BAT_CELL_NUMBER) - \
                              ((BAT_CELL_NUMBER - 1) * CELL_VOLTAGE_SAFETY)

//! Minimum voltage, in mV, to consider battery charged.
#define	BAT_VOLTAGE_LOW      (CELL_VOLTAGE_LOW * BAT_CELL_NUMBER)

//! Minimum voltage, in mV, to consider battery safe to charge.
#define	BAT_VOLTAGE_MIN      (CELL_VOLTAGE_MIN * BAT_CELL_NUMBER)

//! Charge voltage to achieve, in mV, during prequalification mode.
#define BAT_VOLTAGE_PREQUAL	(CELL_VOLTAGE_PREQUAL * BAT_CELL_NUMBER)

#endif // LIIONSPECS_H
