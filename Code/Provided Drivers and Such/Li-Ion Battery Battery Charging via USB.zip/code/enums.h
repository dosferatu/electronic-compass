/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Enums in common for Slave and Master
 *
 *      Contains enumerations of timers and variable specifiers for
 *      time.c and USI.c.\n
 *      These are also used in the Master, and have therefore been
 *      put in a separate file for convenience.
 *
 * \par Application note:
 *      AVR458: Charging Li-Ion Batteries with BC100 \n
 *      AVR463: Charging NiMH Batteries with BC100
 *
 * \par Documentation:
 *      For comprehensive code documentation, supported compilers, compiler
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com \n
 *
 * $Name$
 * $Revision: 2335 $
 * $RCSfile$
 * $URL: http://svn.norway.atmel.com/AppsAVR8/avr458_Charging_Li-Ion_Batteries_with_BC100/trunk/code/IAR/enums.h $
 * $Date: 2007-09-07 10:11:19 +0200 (Fri, 07 Sep 2007) $\n
 ******************************************************************************/

#ifndef ENUMS_H
#define ENUMS_H

//******************************************************************************
// Variable specifiers (for Master-Slave communication)
//******************************************************************************
enum {
	ADR_ADCS = 1,          //!< Indicates that ADCS is read/write target.
	ADR_BATTACTIVE,        //!< Indicates that BattActive is read/write target.
	ADR_BATTDATA,          //!< Indicates that BattData is read/write target.
	ADR_BATTCTRL,          //!< Indicates that BattControl is read/write target.
	ADR_TIMERS             //!< Indicates that timeval is read/write target.
};


//******************************************************************************
// Timers
//******************************************************************************
enum {
	TIMER_USI = 0,          //!< Timer meant for USI.
	TIMER_CHG,              //!< Timer meant for charging.
	TIMER_GEN,              //!< Timer meant for general use.
	TIMER_TEMP,             //!< Timer meant for timing of temperature rise.
	TIMERS                  //!< Number of timers used.
};

#endif // ENUMS_H
