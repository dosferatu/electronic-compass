/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      State menu definition
 * 
 *      Contains the definition of the state menu.\n
 *      The state menu contains all states and adresses to associated functions.
 *
 * \par Application note:
 *      AVRxxx: Lithium-Ion battery charging via USB with ATMega32U4  \n
 *
 * \par Documentation:
 *      For comprehensive code documentation, supported compilers, compiler
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 *
 * $Name$
 * $Revision:$
 * $RCSfile$
 * $URL:$
 * $Date:$\n
 ******************************************************************************/

#include <stdlib.h>

#include "statefunc.h"
#include "charge.h"
#include "main.h"
#include "menu.h"


//******************************************************************************
// State menu (relies on the proper battery type to be defined in main.h!)
//******************************************************************************
#ifdef NIMH
/*! \brief The state menu
 *
 * Contains all the defined states and addresses to their associated functions.
 */
__flash const MENU_STATE_t menu_state[] = {
//  State					State function
  { ST_INIT,            Initialize},
  { ST_BATCON,          BatteryControl},
  { ST_PREQUAL,         Charge},
  { ST_SLEEP,           Sleep},
  { ST_FASTCHARGE,      Charge},
  { ST_LOWRATECHARGE,   Charge},
  { ST_ENDCHARGE,       Charge},	
  { ST_DISCHARGE,       Discharge},
  { ST_ERROR,           Error},
  { 0,                  NULL},
};
#endif // NIMH

#ifdef LIION
/*! \brief The state menu
 *
 * Contains all the defined states and addresses to their associated functions.
 */
//__flash const MENU_STATE_t menu_state[] = {
const MENU_STATE_t menu_state[] = {
//  State		State function
  { ST_INIT,            Initialize},
  { ST_BATCON,          BatteryControl},
  { ST_PREQUAL,         Charge},
  { ST_SLEEP,           Sleep},
  { ST_CCURRENT,        Charge},
  { ST_CVOLTAGE,        Charge},
  { ST_ENDCHARGE,       Charge},	
  { ST_DISCHARGE,       Discharge},
  { ST_ERROR,           Error},
  { ST_CCURRENT_CTRL,   Charge}, //added to suppress active waiting state
  { ST_PREQUAL_CTRL,    Charge}, //added to suppress active waiting state
  { ST_CVOLTAGE_CTRL,    Charge}, //added to suppress active waiting state
  { 0,                  NULL},
};
#endif // LIION
