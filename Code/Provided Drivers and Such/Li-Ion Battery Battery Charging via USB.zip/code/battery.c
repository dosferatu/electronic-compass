/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief
 *      Functions related to battery control and data acquisition.
 *
 *      Contains functions for enabling/disabling batteries, and looking up
 *      their status and specifications using the ADC.
 *
 * \par Application note:
 *      AVRxxx: Lithium-Ion battery charging via USB with ATMega32U4  \n
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler 
 *      settings and supported devices see readme.html
 *
 * \author
 *      Atmel Corporation: http://www.atmel.com \n
 *      Support email: avr@atmel.com
 *
 * 
 * $Name$
 * $Revision:$
 * $RCSfile$
 * $URL:$
 * $Date:$\n
 ******************************************************************************/
#include "config.h"
#include "structs.h"
#include "enums.h"

#ifdef __GNUC__
   #include "lib_mcu/adc/adc.h"
   #include "lib_mcu/timer/time.h"
   #include <avr/eeprom.h>
#elif __ICCAVR__
   #include "adc.h"
   #include "time.h"    
#else
   #error Current COMPILER not supported
#endif

#include "battery.h"
#include "main.h"


#ifdef NIMH
#include "NIMHspecs.h"
#endif // NIMH

#ifdef LIION
#include "LIIONspecs.h"
#endif // LIION

//for test
//#define ALLOW_NO_RID

#include "menu.h"

//******************************************************************************
// Variables
//******************************************************************************
/* Control-struct for batteries */
/*! \brief Holds control data for both batteries
 * \note Stored in EEPROM.
 */

#ifdef __GNUC__
 EEMEM Battery_t BattControl[2] = {{TRUE, TRUE, FALSE},
                                     {TRUE, TRUE, FALSE}};
#elif __ICCAVR__
 __eeprom Battery_t BattControl[2] = {{TRUE, TRUE, FALSE},
                                     {TRUE, TRUE, FALSE}};
#else
   #error Current COMPILER not supported
#endif

/* Data-struct for battery */
Batteries_t BattData; //!< Holds data for the current battery


/* Storage for battery EPROM */
/*! \brief Storage space for data from the batteries' own EPROMs.
 * \note Stored in EEPROM.
 */

#ifdef __GNUC__
EEMEM unsigned char BattEEPROM[4][32];
#elif __ICCAVR__
__eeprom unsigned char BattEEPROM[4][32];
#else
   #error Current COMPILER not supported
#endif

//! Global that indicates current battery (0 = battery A, 1 = B)
unsigned char BattActive;

//for TrustFire battery
unsigned char index_ibat = 0;
//end

/*! \brief RID lookup-table
 *
 * Contains Resistor ID data specified by manufacturer.
 *
 * \note Values have been calculated assuming a +/- 15% tolerance.
 */
const RID_Lookup_t RID[RID_TABLE_SIZE] = {
  {270, 340, 3900, 550, 100, 300, 10},		//EASYPACK 550mA, VREF=5V
  {500, 560, 6800, 750, 100, 300, 14},		//EASYPACK 750mA, VREF=5V
  {740, 820, 10000, 1000, 100, 300, 19},	//EASYPACK 1000mA, VREF=5V
  {1500, 1650, 24000, 2000, 100, 420, 38}		//EASYPACK 2000mA, VREF=5V
};

//FOR VARTA POLYFLEX
/*
const RID_Lookup_t RID[RID_TABLE_SIZE] = {
  {558, 659, 3900, 550, 260, 300, 10},
  {744, 843, 6800, 750, 360, 300, 14},
  {869, 958, 10000, 1000, 475, 300, 19},
  {1097, 1153, 24000, 2000, 475, 420, 38}
};
*/

/*! \brief NTC lookup-table
 *
 * The first entry is 0 degrees. For every entry after, temperature increases
 * with 4 degrees. With 20 entries, the last one equals (20-1)*4 = 76 degrees.\n
 * It must be sorted in descending ADC order.
 *
 * \note This was calculated for a Mitsubishi RH16-3H103FB NTC.
 *
 * \note NTCLookUp() must be modified if this table is changed so that:
 * - first entry is no longer 0 degrees.
 * - temperature difference between entries is no longer 4 degrees.
 * - ADCsteps no longer specifies ADC steps per half degree.
 */
// FOR VARTA POLYFLEX NTC
const NTC_Lookup_t NTC[NTC_TABLE_SIZE] = {
	{1002, 23}, {953, 25}, {902, 26}, {849, 27}, {796, 27},
	{742, 27}, {689, 26}, {637, 26}, {587, 25}, {539, 24},
	{494, 22}, {451, 21}, {412, 19}, {375, 18}, {341, 17},
	{310, 15}, {282, 14}, {256, 13}, {233, 11}, {212, 10}
};


// FOR MITSUBISHI NTC
/*
const NTC_Lookup_t NTC[NTC_TABLE_SIZE] = {
  {1004, 24}, {954, 25}, {903, 26}, {850, 27}, {796, 27},
  {742, 27}, {689, 27}, {637, 26}, {587, 25}, {539, 24},
  {493, 22}, {451, 21}, {411, 20}, {374, 18}, {340, 17},
  {309, 15}, {281, 14}, {255, 13}, {232, 11}, {211, 10}
};
*/


//******************************************************************************
// Functions
//******************************************************************************
/*! \brief Checks if battery has changed
 *
 * Stores current capacity, then attempts to refresh battery status.\n
 * If the refresh is successful, old capacity is compared with the new one.
 * 
 * \retval FALSE Battery is disconnected, or capacity has changed.
 * \retval TRUE All OK.
 */
unsigned char BatteryCheck(void)
{
	unsigned char success = TRUE;
 
	if (!BatteryStatusRefresh()) {
		success = FALSE;              // Battery not present or RID was invalid.
	}

	return(success);
}


/*! \brief Refreshes battery status information
 *
 * Refreshes battery status information, if it is present, based on
 * RID and NTC (read by ADC).\n
 * The battery must have been enabled and a complete set of ADC data must have
 * been collected before calling.\n
 *
 * \retval FALSE No battery present.
 * \retval TRUE Battery present, status refreshed.
 *
 * \note If ALLOW_NO_RID is defined, charging will NOT stop if no fitting entry
 * is found in the lookup table. Instead, default battery data will be used.
 */
unsigned char BatteryStatusRefresh(void)
{
	// Assume the worst..
	unsigned char success = FALSE;
	
	BattData.Present = FALSE;
	BattData.Charged = FALSE;
	BattData.Low = TRUE;
	BattData.Temperature = 0;
	BattData.Capacity = 0;
	BattData.MaxCurrent = 0;         
	BattData.MaxTime = 0;
	BattData.MinCurrent = 0;

	NTCLookUp();
	BattData.HasRID = RIDLookUp();

	// Is the battery voltage above minimum safe cell voltage?
	if (ADCS.VBAT >= BAT_VOLTAGE_MIN) {
		BattData.Low = FALSE;
	}

	// Is the battery charged?
	if (ADCS.VBAT >= BAT_VOLTAGE_LOW) {
		BattData.Charged = TRUE;
	}

	// If we are not charging, yet VBAT is above safe limit, battery is present.
	// If we are charging and there's a current flowing, the battery is present.
	
	/*! \todo If ABORT_IF_PWM_MAX is defined this last check battery presence
	* check is redundant since charging will be aborted due to low current at
	* max duty cycle. That is preferrable since the charge current reading is
	* not 100% proof.
	*/
	if ((!BattData.Low)) {	
		BattData.Present = TRUE;
		success = TRUE;
	} else {
		BattData.Low = FALSE;  // (This is just a technicality..)
		success = FALSE;
	}
	
	//Battery not present
	if(ADCS.VBAT < BAT_VOLTAGE_MIN)
		BattData.Present = FALSE;

//for TrustFire battery: addition of a test
//if batterie is removed during charge => PWM stays started
if((ADCS.avgIBAT == 0)&&
						((CurrentState == ST_PREQUAL)||
						(CurrentState == ST_CCURRENT)||
						(CurrentState == ST_CCURRENT_CTRL)||
						(CurrentState == ST_CVOLTAGE)||
						(CurrentState == ST_CVOLTAGE_CTRL)))
{
	index_ibat++;

	if(index_ibat == 10)
	{
		BattData.Present = FALSE;
		index_ibat = 0;
		success = FALSE;				
	}
}
else
{
		index_ibat = 0;
}
//End

#ifndef ALLOW_NO_RID
	// Return FALSE if no valid RID entry was found, to stop charging.
	if(!BattData.HasRID) {
		success = FALSE;
		BattData.Present = FALSE;		
	}
#endif

	return(success);
}


/*! \brief Refreshes battery data in the EEPROM
 *
 * Attempts to read 4 pages of 32 bytes each from the battery's EPROM and store
 * these data in on-chip EEPROM.\n
 * If unsuccessful (CRC doesn't check out), the on-chip EEPROM is cleared.
 *
 * \todo Updating BattData with these data. Specs needed.
 *
 * \retval FALSE Refresh failed.
 * \retval TRUE Refresh successful.
 */
unsigned char BatteryDataRefresh(void)
{
#if 0  //if needed EEPROM can store data
  
	unsigned char offset;
	unsigned char i, crc, family, temp, page;
	unsigned char success;
	
//tbd

	// Erase local EEPROM page if there were any errors during transfer.
	if (!success) {
		for (i=0; i<32; i++) {
			BattEEPROM[page][i] = 0;
		}
	}

	return(success);
#endif
//before implementation
return(1);	
}

#if 0 //Not applicable on 32U4
/*! \brief Enables specified battery
 *
 * Updates \ref BattActive to specified battery, then sets PB4/PB5 and clears
 * PB5/PB4 in PORTB, depending on which battery is specified.\n
 * The function takes 100 ms to allow the port switch to settle.
 *
 * \param bat Specifies which battery to enable (0 = battery A, 1 = B)
 */
void EnableBattery(unsigned char bat)
{
	// Use general timer, set timeout to 100ms.
	Time_Set(TIMER_GEN,0,0,100);

	// Set specified battery as the active one.
	BattActive = bat;

	// Enable current battery in hardware, light LED & connect battery.
	PORTB |= (1 << (PB4+bat));

	// Disconnect other battery.
	PORTB &= ~(1<<(PB5-bat));     

	do { // Let port switch settle.
	} while (Time_Left(TIMER_GEN));  
}


/*! \brief Disables both batteries
 *
 * Clears PB4 and PB5 in PORTB, disabling both batteries.
 */
void DisableBatteries(void)
{
	// Turn off LEDs and disconnect batteries.
	PORTB &= ~((1<<PB4)|(1<<PB5));  
}
#endif

/*! \brief Looks up battery data from RID table
 *
 * Attempts to find data for the battery from the RID lookup-table.\n
 * If no valid entry is found, default data (defined in battery.h)
 * are used.
 *
 * \retval TRUE Entry found, battery data updated.
 * \retval FALSE No entry found, using defaults for battery data.
 */
unsigned char RIDLookUp (void)
{
	unsigned char i, found = FALSE;

	// Lookup in the RID-table. If measured RID is within the limits
	// of an entry, those data are used, and TRUE is returned.
	for (i = 0 ; i < RID_TABLE_SIZE; i++) {
		if (ADCS.rawRID >= RID[i].Low) {
			if (ADCS.rawRID <= RID[i].High) {
				BattData.Capacity = RID[i].Capacity;
				BattData.MaxCurrent = RID[i].Icharge;
				BattData.MaxTime = RID[i].tCutOff;
				BattData.MinCurrent = RID[i].ICutOff;
				
				found = TRUE;
			}
		}
	}
	
	// If no valid entry is found, use defaults and return FALSE.
	if (!found) {
		BattData.Capacity = DEF_BAT_CAPACITY;
		BattData.MaxCurrent = DEF_BAT_CURRENT_MAX;
		BattData.MaxTime = DEF_BAT_TIME_MAX;
		BattData.MinCurrent = DEF_BAT_CURRENT_MIN;
	}
	
	return(found);
}


/*! \brief Calculates temperature from a lookup table
 *
 * Looks up the highest NTC value below or equal to the measured one.\n
 * With the current lookup table, temperature is calculated with the formula:\n
 * 4*(index of entry) - 2*(measured NTC - NTC from entry) / (ADCsteps of entry)
 *
 * \note If the NTC-measurement is saturated, with the current lookup table,
 * the temperature will be reported as -1 C.
 *
 * \note If no valid entry is found, battery temperature is set to 80.
 */
void NTCLookUp (void)
{
	unsigned char i;
	unsigned char found = FALSE;
	
	// Lookup in the NTC-table. Use the first entry which is equal or below
	// sampled NTC. Calculate temperature by using the index number, and the
	// difference between the measured NTC value and the one in the entry.
	for (i=0 ; (i < NTC_TABLE_SIZE) && (!found); i++)	{
		if (ADCS.rawNTC >= NTC[i].TADC) {
			BattData.Temperature = (i<<2) ;
			BattData.ADCSteps = NTC[i].ADCsteps;  
			BattData.Temperature -= ((ADCS.rawNTC - NTC[i].TADC)<<1) / BattData.ADCSteps;
			
			found = TRUE;  // Could be done with a break, but that violates MISRA.
		}
	}
	
	// For safety, is temperature is greater than the NTC 
	if (!found) {
		BattData.Temperature = 80;
		BattData.Present = FALSE;		
	}
}
